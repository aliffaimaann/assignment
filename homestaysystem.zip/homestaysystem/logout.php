<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="logoutstyle.css">
</head>
<body>
  <div class="container">
    <h1>LOGOUT</h1>
    <p>ARE YOU SURE YOU WANT TO LOG OUT ?</p>
    <button id="logoutBtn">Logout</button>
  </div>

  <script src="script.js"></script>
</body>
</html>

