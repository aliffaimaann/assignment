<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .navbar {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
            background: #000;
            color: #fff;
            font-size: 24px;
            padding: 0 20px;
        }

        .navbar-text img {
            width: 85px;
            height: 95px;
            margin-right: 45px;
        }

        .dropdown {
            margin-right: 20px;
        }

        .dropbtn {
            background-color: black;
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            display: flex;
            align-items: center;
        }

        .dropbtn i {
            margin-right: 5px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            right: 0;
        }

        .dropdown-content a {
            color: #fff;
            padding: 12px 16px;
            font-size: 14px;
            text-decoration: none;
            display: block;
            background-color: #333;
        }

        .dropdown-content a:hover {
            color: green;
            background-color: #03f40f;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            flex: 0 0 200px;
            background-color: #333;
            color: #fff;
            padding: 25px;
        }

        .sidebar h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s, background-color 0.3s;
        }

        .sidebar a:hover {
            color: #000;
            background-color: #fff;
        }

        .sidebar a.active {
            color: #000;
            background-color: #fff;
        }

        .content {
            flex: 1;
            padding: 20px;
            background-color: #f2f2f2;
        }

        .content h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .content p {
            margin-bottom: 10px;
        }

        .profile-sidebar {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .profile-userpic img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile-usertitle {
            display: flex;
            flex-direction: column;
        }

        .profile-usertitle-name {
            font-weight: bold;
            font-size: 16px;
        }

        .profile-usertitle-status {
            font-size: 14px;
        }

        .profile-usertitle .indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }

        .label-success {
            background-color: green;
        }

        .divider {
            margin-bottom: 20px;
            border-bottom: 1px solid #fff;
        }

        .sidebar-image {
            background-image: url("img/user.png");
            background-size: cover;
            background-position: center;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
            margin-right: 10px;
            float: left;
        }

        .sidebar-heading {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form {
        background-color: #444444;
        border-radius: 10px;
        padding: 20px;
        margin: 50px auto;
        margin-top: 100px;
        margin-left: 450px;
        max-width: 500px; /* Adjust the maximum width as needed */
        width: 100%;
        padding-bottom: 40px; /* Adjust the padding-bottom value as needed */
        padding-top: 20px;
       }

        .lb {
            display: block;
            margin-bottom: 4px;
            font-size: 18px;
            font-weight: bold;
        }

        .infos[type="text"],
        input[type="name"],
        input[type="time"] {
            width: 95%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: none;
            margin-bottom: 10px;
            background-color: #333333;
            color: white;
        }

        #limpar {
            --glow-color: rgb(255, 176, 176);
            --glow-spread-color: rgba(255, 123, 123, 0.781);
            --enhanced-glow-color: rgb(182, 175, 71);
            --btn-color: rgba(241, 13, 13, 0.508);
            border: .25em solid var(--glow-color);
            padding: 1em 2em;
            color: var(--glow-color);
            font-size: 14px;
            font-weight: bold;
            background-color: var(--btn-color);
            border-radius: 1em;
            outline: none;
            box-shadow: 0 0 1em .25em var(--glow-color),
              0 0 4em 1em var(--glow-spread-color),
              inset 0 0 .05em .25em var(--glow-color);
            text-shadow: 0 0 .5em var(--glow-color);
            position: relative;
            transition: all 0.3s;
        }

        #limpar::after {
            pointer-events: none;
            content: "";
            position: absolute;
            top: 120%;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: var(--glow-spread-color);
            filter: blur(2em);
            opacity: .7;
            transform: perspective(1.5em) rotateX(35deg) scale(1, .6);
        }

        #limpar:hover {
            color: var(--btn-color);
            background-color: var(--glow-color);
            box-shadow: 0 0 1em .25em var(--glow-color),
              0 0 4em 2em var(--glow-spread-color),
              inset 0 0 .75em .25em var(--glow-color);
        }

        #limpar:active {
            box-shadow: 0 0 0.6em .25em var(--glow-color),
              0 0 2.5em 2em var(--glow-spread-color),
              inset 0 0 .5em .25em var(--glow-color);
        }

        @media (min-width: 700px) {
            form {
                width: 450px;
                margin: 35px auto;
            }
        }
        
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="navbar-text">
            <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
        </div>
        <div class="dropdown">
            <button class="dropbtn">Administrator</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <div class="sidebar">
            <div class="profile-sidebar">
                <div class="sidebar-image"></div>
                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">Admin</div>
                    <div class="profile-usertitle-status"><span class="indicator label-success"></span>Manager</div>
                </div>
            </div>
            <div class="divider"></div>
            <ul class="nav menu">
                <li>
                    <a href="home.php">
                        <h1>Dashboard</h1>
                    </a>
                </li>
                <li>
                    <a href="staff_mang.php">
                        <h1>Staff Section</h1>
                    </a>
                </li>
                <li>
                    <a href="schedule.php">
                        <h1>Schedule</h1>
                    </a>
                </li>
                <li>
                    <a href="workschedule.php">
                        <h1>Work Schedule</h1>
                    </a>
                </li>
                <li>
                    <a href="report.php">
                        <h1>Generate Report</h1>
                    </a>
                </li>
            </ul>
    </div>

    

<div>
    <form class="form" action="addschedule_process.php" method="POST">
        <h3><b>HOUSEKEEPING DUTY ROOM:</b></h3>

        <label for="staffID" class="lb">Staff ID:</label>
        <input type="text" id="staffID" name="StaffID" class="infos" placeholder="STAFF ID" value="<?php echo isset($_GET['staffID']) ? $_GET['staffID'] : ''; ?>" readonly>
        
        <label for="roomCode" class="lb">Room Code:</label>
        <input type="text" id="roomCode" name="RoomCode" class="infos" placeholder="ROOM CODE" value="">

        <br><br>
        <button id="limpar" type="submit" name="add">ADD</button>
        <button id="limpar" type="button" onclick="goToSchedulePage()">CANCEL</button>

        <script>
            function goToSchedulePage() {
                // Redirect to schedule.php
                window.location.href = "schedule.php";
            }
        </script>
    </form>
</div>
