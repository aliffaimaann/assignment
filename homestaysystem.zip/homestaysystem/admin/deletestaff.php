<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .navbar {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
            background: #000;
            color: #fff;
            font-size: 24px;
            padding: 0 20px;
        }

        .navbar-text img {
            width: 85px;
            height: 95px;
            margin-right: 45px;
        }

        .dropdown {
            margin-right: 20px;
        }

        .dropbtn {
            background-color: black;
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            display: flex;
            align-items: center;
        }

        .dropbtn i {
            margin-right: 5px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            right: 0;
        }

        .dropdown-content a {
            color: #fff;
            padding: 12px 16px;
            font-size: 14px;
            text-decoration: none;
            display: block;
            background-color: #333;
        }

        .dropdown-content a:hover {
            color: green;
            background-color: #03f40f;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 200px;
            background-color: #333;
            color: #fff;
            padding: 25px;
            
        }

        .sidebar h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s, background-color 0.3s;
        }

        .sidebar a:hover {
            color: #000;
            background-color: #fff;
        }

        .sidebar a.active {
            color: #000;
            background-color: #fff;
        }

        .content {
            flex: 1;
            padding: 20px;
            background-color: #f2f2f2;
        }

        .content h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .content p {
            margin-bottom: 10px;
        }

        .profile-sidebar {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .profile-userpic img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile-usertitle {
            display: flex;
            flex-direction: column;
        }

        .profile-usertitle-name {
            font-weight: bold;
            font-size: 16px;
        }

        .profile-usertitle-status {
            font-size: 14px;
        }

        .profile-usertitle .indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }

        .label-success {
            background-color: green;
        }

        .divider {
            margin-bottom: 20px;
            border-bottom: 1px solid #fff;
        }

        .sidebar-image {
            background-image: url("img/user.png");
            background-size: cover;
            background-position: center;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
            margin-right: 10px;
            float: left;
        }

        .sidebar-heading {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .panel-widget {
            text-align: center;
            padding: 20px;
        }

        .panel-widget .fa-xl {
            font-size: 48px;
            margin-bottom: 10px;
        }

        .panel-widget .large {
            font-size: 24px;
        }

        .panel-widget .text-muted {
            font-size: 14px;
        }

        .panel-container {
            padding: 20px;
            background-color: #9791A1;
        }

        .panel-container hr {
            margin-top: 30px;
            margin-bottom: 30px;
            border-top: 1px solid #ddd;
        }

        .panel-staff {
            order: 3;
            margin-left: auto;
        }

        .panel-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .panel-heading h3 {
            margin: 0;
        }

        .panel-heading .btn {
            background-color: #333;
            color: #fff;
            padding: 8px 16px;
            font-size: 14px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            display: flex;
            align-items: center;
        }

        .panel-heading .btn i {
            margin-right: 5px;
        }

        .panel-heading .btn:hover {
            background-color: black;
        }

        .staff-table {
            width: 100%;
            margin-top: 20px;
        }
        
        .staff-table th {
            padding: 10;
            background-color: #000;
            color: #fff;
            text-align: center;
        }

        .staff-table td {
            padding: 10px;
            background-color: black;
            color: #fff;
            text-align: left;
        }

        .staff-table th {
            background-color: #333;
            color: #fff;
        }

        .staff-table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .add-staff-button {
        outline: none;
        cursor: pointer;
        border: none;
        padding: 0.9rem 2rem;
        margin: 0;
        font-family: inherit;
        font-size: inherit;
        font-weight: 700;
        font-size: 17px;
        border-radius: 500px;
        overflow: hidden;
        background: #CCC5D1;
        color: ghostwhite;
        float: right; /* Add this line to align the button to the right */
        margin-top: 5px; /* Adjust the margin-top as needed */
       }

        .add-staff-button span {
            position: relative;
            z-index: 10;
            transition: color 0.4s;
        }

        .add-staff-button:hover span {
            color: black;
        }

        .add-staff-button::before,
        .add-staff-button::after {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }

        .section_form {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Use min-height instead of height to ensure it fits the page even with smaller content */
        }


        .feed-form {
            margin-top: 5px;
            margin-left: 500px;
            display: flex;
            flex-direction: column;
            width: 100%; /* Set the width to 100% to fit the parent container */
            max-width: 500px; /* Limit the maximum width of the form */
            align-items: center; /* Center align the form horizontally */
        }


        .feed-form input {
            height: 54px;
            width: 500px;
            border-radius: 5px;
            background: white;
            margin-bottom: 15px;
            border: none;
            padding: 0 20px;
            font-weight: 300;
            font-size: 14px;
            color: #4B4B4B;
        }

        .button_submit:hover,
        .feed-form input:hover {
            transform: scale(1.009);
            box-shadow: 0px 0px 3px 0px #212529;
        }

        .button_submit {
            width: 100%;
            height: 54px;
            font-size: 14px;
            color: white;
            background: #000000;
            border-radius: 5px;
            margin-top: 20px;
            border: none;
            font-weight: 500;
            text-transform: uppercase;
        }

        
</style>


</head>
<body>
    <nav class="navbar">
        <div class="navbar-text">
            <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
        </div>
        <div class="dropdown">
            <button class="dropbtn">Administrator</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <div class="sidebar">
            <div class="profile-sidebar">
                <div class="sidebar-image"></div>
                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">Admin</div>
                    <div class="profile-usertitle-status"><span class="indicator label-success"></span>Manager</div>
                </div>
            </div>
            <div class="divider"></div>
            <ul class="nav menu">
                <li>
                    <a href="home.php"><h1>Dashboard</h1></a>
                </li>
                <li>
                    <a href="staff_mang.php"><h1>Staff Section</h1></a>
                </li>
                <li>
                    <a href="schedule.php"><h1>Schedule</h1></a>
                </li>
                <li>
                    <a href="workschedule.php"><h1>Work Schedule</h1></a>
                </li>
                <li>
                    <a href="report.php"><h1>Generate Report</h1></a>
                </li>
            </ul>
        </div>

        <?php
        // Include db.php file
        include 'db.php';

        // Check if the staff ID is provided as a query parameter
        if (isset($_GET['staffID'])) {
            $staffID = $_GET['staffID'];

            // Query to retrieve the staff details based on the staff ID
            $query = "SELECT * FROM staff WHERE StaffID = $staffID";

            // Execute the query
            $result = mysqli_query($connection, $query);

            // Check if the query execution was successful
            if ($result && mysqli_num_rows($result) > 0) {
                // Fetch the staff details
                $staff = mysqli_fetch_assoc($result);
                $staffID = $staff['StaffID'];
                $staffName = $staff['StaffName'];
                $staffPhNum = $staff['StaffPhNum'];
                $staffAddress = $staff['StaffAddress'];
                ?>

                
          <section class="section_form">
            <form id="consultation-form" class="feed-form" action="delete.php" method="POST">
                <input type="hidden" name="staffID" value="<?php echo $staffID; ?>">
                <div class="form-group">
                    <label for="staffName">Staff Name:</label>
                    <input type="text" name="staffName" class="form-control" placeholder="STAFF NAME" value="<?php echo $staffName; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="staffPhNum">Staff Phone Number:</label>
                    <input type="text" name="staffPhNum" class="form-control" placeholder="PHONE NUMBER" value="<?php echo $staffPhNum; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="staffAddress">Staff Address:</label>
                    <input type="text" name="staffAddress" class="form-control" placeholder="ADDRESS" value="<?php echo $staffAddress; ?>" readonly>
                </div>
                <button type="submit" class="button_submit">DELETE</button>
            </form>
         </section>



            <?php
            } else {
                echo '<div class="content">Staff not found.</div>';
            }
        }

        // Close the database connection
        mysqli_close($connection);
        ?>
