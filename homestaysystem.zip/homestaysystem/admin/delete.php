<?php
// Include db.php file
include 'db.php';

// Check if the form is submitted and the staff ID is provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['staffID'])) {
    // Retrieve the staff ID from the form
    $staffID = $_POST['staffID'];

    // Delete the staff record from the database
    $query = "DELETE FROM staff WHERE StaffID = $staffID";

    // Execute the query
    $result = mysqli_query($connection, $query);

    // Check if the query execution was successful
    if ($result) {
        // Redirect back to the staff management page with a success message
        echo "<script>
                alert('Staff record deleted successfully');
                window.location.href = 'staff_mang.php';
              </script>";
        exit();
    } else {
        // Error in executing the query
        echo 'Error: ' . mysqli_error($connection);
    }
}

// Close the database connection
mysqli_close($connection);


?>
