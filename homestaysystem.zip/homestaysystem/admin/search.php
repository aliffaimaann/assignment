<?php
include 'db.php';

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_POST['search'])) {
    $searchTerm = $_POST['searchTerm'];
    $results = array();

    // Prepare and execute the search query
    $sql = "SELECT * FROM staff WHERE StaffID LIKE '%$searchTerm%' OR StaffName LIKE '%$searchTerm%'";
    $result = $connection->query($sql);

    // Fetch the search results
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
    }
}

// Close the database connection
$connection->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Results</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <?php if (isset($_POST['search'])): ?>
        <?php if (count($results) > 0): ?>
            <h2>Staff Details</h2>
            <table>
                <thead>
                    <tr>
                        <th>StaffID</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>StaffName</th>
                        <th>StaffPhNum</th>
                        <th>StaffAddress</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $result): ?>
                        <tr>
                            <td><?php echo $result['StaffID']; ?></td>
                            <td><?php echo $result['username']; ?></td>
                            <td><?php echo $result['password']; ?></td>
                            <td><?php echo $result['StaffName']; ?></td>
                            <td><?php echo $result['StaffPhNum']; ?></td>
                            <td><?php echo $result['StaffAddress']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No results found.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>
