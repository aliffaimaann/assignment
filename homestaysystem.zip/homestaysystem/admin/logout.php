<?php

session_start();
unset($_SESSION['id']);
unset($_SESSION['username']);
session_abort();
header('Location:login.php');