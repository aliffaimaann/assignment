<?php
// Include the necessary database connection file (db.php)
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add"])) {
    // Retrieve the submitted form data
    $staffID = $_POST["StaffID"];
    $roomCode = $_POST["RoomCode"];
    $scheduleTime = $_POST["ScheduleTime"];

    // Check if a schedule with the same StaffID already exists
    $existingQuery = "SELECT * FROM schedule WHERE StaffID = '$staffID'";
    $existingResult = mysqli_query($connection, $existingQuery);

    if (mysqli_num_rows($existingResult) > 0) {
        // Update the room code in the existing schedule
        $updateQuery = "UPDATE schedule SET RoomCode = '$roomCode' WHERE StaffID = '$staffID'";
        $updateResult = mysqli_query($connection, $updateQuery);

        if ($updateResult) {
            // Schedule updated successfully, redirect to schedule.php
            header("Location: schedule.php");
            exit();
        } else {
            // Error occurred while updating the schedule
            echo 'Error: ' . mysqli_error($connection);
        }
    } else {
        // Insert the new schedule into the database
        $insertQuery = "INSERT INTO schedule (StaffID, RoomCode, ScheduleTime) VALUES ('$staffID', '$roomCode', '$scheduleTime')";
        $insertResult = mysqli_query($connection, $insertQuery);

        if ($insertResult) {
            // Schedule added successfully, redirect to schedule.php
            header("Location: schedule.php");
            exit();
        } else {
            // Error occurred while adding the schedule
            echo 'Error: ' . mysqli_error($connection);
        }
    }
}

// Close the database connection
mysqli_close($connection);