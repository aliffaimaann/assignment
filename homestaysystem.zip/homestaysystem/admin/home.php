<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css"/>
    <style>
        body {
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .navbar {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
            background: #000;
            color: #fff;
            font-size: 24px;
            padding: 0 20px;
        }

        .navbar-text img {
            width: 85px;
            height: 95px;
            margin-right: 45px;
        }

        .dropdown {
            margin-right: 20px;
        }

        .dropbtn {
            background-color: black;
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            display: flex;
            align-items: center;
        }

        .dropbtn i {
            margin-right: 5px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            right: 0;
        }

        .dropdown-content a {
            color: #fff;
            padding: 12px 16px;
            font-size: 14px;
            text-decoration: none;
            display: block;
            background-color: #333;
        }

        .dropdown-content a:hover {
            color: green;
            background-color: #03f40f;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 200px;
            background-color: #333;
            color: #fff;
            padding: 20px;
        }

        .sidebar h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s, background-color 0.3s;
        }

        .sidebar a:hover {
        color: yellow;
        background-color: black;
        }


        .sidebar a.active {
            color: #000;
            background-color: black;
        }

        .content {
            flex: 1;
            padding: 20px;
            background-color: #f2f2f2;
        }

        .content h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .content p {
            margin-bottom: 10px;
        }

        .profile-sidebar {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .profile-userpic img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile-usertitle {
            display: flex;
            flex-direction: column;
        }

        .profile-usertitle-name {
            font-weight: bold;
            font-size: 16px;
        }

        .profile-usertitle-status {
            font-size: 14px;
        }

        .profile-usertitle .indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }

        .label-success {
            background-color: green;
        }

        .divider {
            margin-bottom: 20px;
            border-bottom: 1px solid #fff;
        }

        .sidebar-image {
            background-image: url("img/user.png");
            background-size: cover;
            background-position: center;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
            margin-right: 10px;
            float: left;
        }

        .sidebar-heading {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .panel-container {
            max-width: 100%;
            overflow-x: auto;
            display: flex;
            flex-wrap: wrap; /* Allows the panels to wrap when the screen is smaller */
            justify-content: center; /* Centers the panels horizontally */
        }

        .panel-icon {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Added styles to fit the screen */
        .panel-container {
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            max-width: 100%;
            overflow-x: auto;
        }

        .panel-content {
            display: flex;
            text-align: center;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
        }

        .panel-row {
            display: flex;
            justify-content: center;
            margin-bottom: 60px;
        }
        
        .panel-row .panel-content {
            margin: 0 150px;
        }
        .panel-icon-container {
            margin-bottom: 20px;
        }
        .large {
            margin-top: 10px;
        }
        .text-muted {
            margin-top: 5px;
        }

</style>

</head>
<body>
    <nav class="navbar">
        <div class="navbar-text">
            <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
        </div>
        <div class="dropdown">
            <button class="dropbtn">Administrator</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <div class="sidebar">
            <div class="profile-sidebar">
                <div class="sidebar-image"></div>
                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">Admin</div>
                    <div class="profile-usertitle-status"><span class="indicator label-success"></span>Manager</div>
                </div>
            </div>
            <div class="divider"></div>
            <ul class="nav menu">
                <li>
                    <a href="home.php"><h1>Dashboard</h1></a>
                </li>
                <li>
                    <a href="staff_mang.php"><h1>Staff Section</h1></a>
                </li>
                <li>
                    <a href="schedule.php"><h1>Schedule</h1></a>
                </li>
                <li>
                    <a href="workschedule.php"><h1>Work Schedule</h1></a>
                </li>
                <li>
                    <a href="report.php"><h1>Generate Report</h1></a>
                </li>
            </ul>
        </div>

        <div class="panel-container">
            <div class="panel-row">
                <div class="panel-content">
                    <div class="panel-icon-container">
                        <i class="fa fa-xl fa-bookmark" style="font-size: 150px;"></i>
                    </div>
                    <div class="large"><?php include 'counters/reserve-count.php'?></div>
                    <div class="text-muted">Reservations</div>
                </div>
                <div class="panel-content">
                    <div class="panel-icon-container">
                        <i class="fa fa-xl fa-users" style="font-size: 150px;"></i>
                    </div>
                    <div class="large"><?php include 'counters/staff-count.php'?></div>
                    <div class="text-muted">Staff</div>
                </div>
                <div class="panel-content">
                    <div class="panel-icon-container">
                        <i class="fa fa-xl fa-calendar" style="font-size: 150px;"></i>
                    </div>
                    <div class="large"><?php include 'counters/checkedin-count.php'?></div>
                    <div class="text-muted">Check-ins Today</div>
                </div>
            </div>
            <div class="panel-row">
                <div class="panel-content">
                    <div class="panel-icon-container">
                        <i class="fa fa-xl fa-bed" style="font-size: 150px;"></i>
                    </div>
                    <div class="large"><?php include 'counters/bookedroom-count.php'?></div>
                    <div class="text-muted">Booked Rooms</div>
                </div>
                <div class="panel-content">
                    <div class="panel-icon-container">
                        <i class="fa fa-xl fa-check" style="font-size: 150px;"></i>
                    </div>
                    <div class="large"><?php include 'counters/checkedout-count.php'?></div>
                    <div class="text-muted">Check-outs Today</div>
                    </div>
                </div>
            </body>
        </html>
