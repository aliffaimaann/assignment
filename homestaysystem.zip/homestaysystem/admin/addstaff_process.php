<?php
include 'db.php';

// Retrieve form data
$fullName = $_POST['fullName'];
$username = $_POST['username'];
$password = $_POST['password'];
$phoneNumber = $_POST['phoneNumber'];
$address = $_POST['address'];

// Sanitize input values
$fullName = mysqli_real_escape_string($connection, $fullName);
$username = mysqli_real_escape_string($connection, $username);
$password = mysqli_real_escape_string($connection, $password);
$phoneNumber = mysqli_real_escape_string($connection, $phoneNumber);
$address = mysqli_real_escape_string($connection, $address);

// Insert new staff member into the database
$sql = "INSERT INTO staff (username, password, StaffName, StaffPhNum, StaffAddress) VALUES ('$username', '$password', '$fullName', '$phoneNumber', '$address')";
$result = mysqli_query($connection, $sql);

if ($result) {
    // Display success message
    echo "<script>alert('New staff member added successfully!');</script>";
    header('Location: staff_mang.php');
    exit;
} else {
    // Display failure message
    echo "<script>alert('Adding new staff member failed.');</script>";
}
?>
