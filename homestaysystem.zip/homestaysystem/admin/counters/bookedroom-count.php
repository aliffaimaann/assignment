<?php 
    include './db.php';
    $sql = "SELECT * FROM room WHERE RoomFacilitiesChosen = 'BANQUET FACILITIES'";
    $query = $connection->query($sql);

    echo "$query->num_rows";

?>