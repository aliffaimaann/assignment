<?php 
    $servername = "localhost";  // Replace with your database server name
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $dbname = "homestay"; // Specify the name of the database
    
    // Create a connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    $sql = "SELECT * FROM room WHERE RoomCin = '2023-05-20 16:00:00'";
    $query = $connection->query($sql);

    echo "$query->num_rows";

?>