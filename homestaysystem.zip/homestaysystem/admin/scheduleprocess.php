<?php
// Include the necessary database connection file (db.php)
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["change"])) {
    // Retrieve the submitted schedule time and staff ID
    $newScheduleTime = $_POST["ScheduleTime"];
    $StaffID = $_POST["StaffID"];

    // Retrieve the ScheduleID for the selected staff
    $query = "SELECT ScheduleID FROM schedule WHERE StaffID = $StaffID";
    $result = mysqli_query($connection, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        // Fetch the row and retrieve the ScheduleID
        $row = mysqli_fetch_assoc($result);
        $ScheduleID = $row['ScheduleID'];

        // Update the schedule time
        $updateQuery = "UPDATE schedule SET ScheduleTime = '$newScheduleTime' WHERE ScheduleID = $ScheduleID";

        $updateResult = mysqli_query($connection, $updateQuery);

        if ($updateResult) {
            // Schedule time updated successfully, redirect to schedule.php
            header("Location: schedule.php");
            exit();
        } else {
            // Error occurred while updating the schedule time
            echo 'Error: ' . mysqli_error($connection);
        }
    } else {
        // No schedule found for the selected staff
        echo 'No schedule found for the selected staff.';
    }
}

// Close the database connection
mysqli_close($connection);
?>
