<?php
    include './db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
  $result = mysqli_query($connection, $query);

  if (mysqli_num_rows($result) == 1) {
    // Valid login
    $row = mysqli_fetch_assoc($result);
    header("Location: home.php"); // Redirect to home.php
    exit();
  } else {
    // Invalid login
    echo "<script>
      alert('You are not an admin!');
      window.location.href = 'loginadmin.php';
      
    </script>";
  }
}
?>
