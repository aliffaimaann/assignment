<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="reportstyle.css">
</head>
<body>
    <nav class="navbar">
        <div class="navbar-text">
            <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
        </div>
        <div class="dropdown">
            <button class="dropbtn">Administrator</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <div class="sidebar">
            <div class="profile-sidebar">
                <div class="sidebar-image"></div>
                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">Admin</div>
                    <div class="profile-usertitle-status"><span class="indicator label-success"></span>Manager</div>
                </div>
            </div>
            <div class="divider"></div>
            <ul class="nav menu">
                <li>
                    <a href="home.php"><h1>Dashboard</h1></a>
                </li>
                <li>
                    <a href="staff_mang.php"><h1>Staff Section</h1></a>
                </li>
                <li>
                    <a href="schedule.php"><h1>Schedule</h1></a>
                </li>
                <li>
                    <a href="workschedule.php"><h1>Work Schedule</h1></a>
                </li>
                <li>
                    <a href="report.php"><h1>Generate Report</h1></a>
                </li>
            </ul>
        </div>

                    <div class="content">
                <div class="panel-container">
            <h2>Statistics:</h2>

                <div class="panel-heading">
                <button class="add-staff-button" onclick="window.print()"><span>PRINT</span></button>
        </div>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Room', 'Count'],
          ['Dahlia', 2],
          ['Rose',  14],
          ['Cempaka', 4],
          ['Orkid', 5],
          ['Melor', 5],
        
        ]);

        var options = {
          title: 'Room Reserved Rates',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>

 <script type="text/javascript">
    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Month", "Profit", { role: "style" } ],
        ["May", 18350.00, "#b87333"],
        ["June", 550.00, "silver"],
        ["July", 450.00, "gold"],
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Monthly Profit",
        width: 410,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
      chart.draw(view, options);
  }
  </script>
  <script type="text/javascript">
      google.charts.load("current", {packages:["calendar"]});
      google.charts.setOnLoadCallback(drawChart);

   function drawChart() {
       var dataTable = new google.visualization.DataTable();
       dataTable.addColumn({ type: 'date', id: 'Date' });
       dataTable.addColumn({ type: 'number', id: 'Room Booked' });
       dataTable.addRows([
          [ new Date(2023, 5, 10), 1   ],
          [ new Date(2023, 5, 13), 1   ],
          [ new Date(2023, 5, 17), 2   ],
          [ new Date(2023, 5, 21), 1   ],
          [ new Date(2023, 5, 22), 2   ],
           //
          [ new Date(2023, 6, 13), 5   ],
          [ new Date(2023, 6, 14), 9 ],
          [ new Date(2023, 6, 15), 5 ],
          [ new Date(2023, 6, 16), 6 ],
          [ new Date(2023, 6, 17), 2 ],
          // Many rows omitted for brevity.
          [ new Date(2023, 6, 4), 3 ],
          [ new Date(2023, 6, 5), 5],
          [ new Date(2023, 6, 12), 6],
          [ new Date(2023, 6, 13), 7],
          [ new Date(2023, 6, 19), 1 ],
          [ new Date(2023, 6, 23), 3],
          [ new Date(2023, 7, 24), 5],
          [ new Date(2023, 7, 30), 2 ]
        ]);

       var chart = new google.visualization.Calendar(document.getElementById('calendar_basic'));

       var options = {
         title: "Reserved Room on Different Day",
         height: 450,
       };

       chart.draw(dataTable, options);
   }
</script>
  </head>
    <div id="piechart_3d"></div>
    <div id="barchart_values"></div><br><br><br>
    <div id="calendar_basic"></div>
</body>
</html>