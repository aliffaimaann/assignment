<?php
// Include db.php file
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the updated staff details from the form
    $staffID = $_POST['staffID'];
    $staffName = $_POST['staffName'];
    $staffPhNum = $_POST['staffPhNum'];
    $staffAddress = $_POST['staffAddress'];

    // Update the staff details in the database
    $query = "UPDATE staff SET
              StaffName = '$staffName',
              StaffPhNum = '$staffPhNum',
              StaffAddress = '$staffAddress'
              WHERE StaffID = $staffID";

    // Execute the query
    $result = mysqli_query($connection, $query);

    // Check if the query execution was successful
    if ($result) {
        // Redirect back to the staff management page
        header("Location: staff_mang.php");
        exit();
    } else {
        // Error in executing the query
        echo 'Error: ' . mysqli_error($connection);
    }
}

// Close the database connection
mysqli_close($connection);
?>
