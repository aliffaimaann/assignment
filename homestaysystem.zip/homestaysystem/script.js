document.getElementById("logoutBtn").addEventListener("click", function() {
  // Perform logout functionality here
  alert("YOU HAVE SUCCESSFULLY LOGOUT!");
  alert("*all changes successfully saved");
  
  window.location.href = "index2.php";
});
