<!DOCTYPE html>
<html>
<head>
    <title>Booking Details</title>
</head>
<body>
    <h1>Booking Details</h1>
    <?php
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve the booking ID from the form
            $booking_id = $_POST["booking_id"];
            
            // Perform a search in your database based on the booking ID
            // Replace this with your own database connection and query code
            $db_host = "your_host";
            $db_username = "your_username";
            $db_password = "your_password";
            $db_name = "your_database_name";

            // Create a database connection
            $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Prepare and execute the query
            $sql = "SELECT * FROM bookings WHERE id = '$booking_id'";
            $result = mysqli_query($conn, $sql);

            // Check if any rows are returned
            if (mysqli_num_rows($result) > 0) {
                // Display the booking details
                $row = mysqli_fetch_assoc($result);
                echo "<p><strong>Booking ID:</strong> " . $row["id"] . "</p>";
                echo "<p><strong>Name:</strong> " . $row["name"] . "</p>";
                echo "<p><strong>Email:</strong> " . $row["email"] . "</p>";
                // Add more details as needed
            } else {
                echo "No booking found with the provided ID.";
            }

            // Close the database connection
            mysqli_close($conn);
        }
    ?>
</body>
</html>
