<html>
<head>
     <meta name="viewreport" content="width=device-width, initial-scale=1.0">
	 <title>MENU</title>
	 <link rel="stylesheet" href="stylemenu.css">
	 
	 <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
 </head>
 <body>
      <div class="container">
	    <div class="navbar">
		  <img src="images/logo.png" class="logo">
		  <nav>
		     <ul>
			   <li><a href="mainmenu.php">HOME</a></li>
			   <li><a href="login_menu.php">LOG IN</a></li>
			   <li><a href="about.php">ABOUT</a></li>
			 </ul>
			 </nav>
			 <img src="images/menu.png" class="menu-icon">
		   </div>
	  
	  <div class="row">
	    <div class="col">
		  <h1>Homestay</h1>
		  <p><i>If you are looking for where to go and how to do it, then our homestay is the right spot for you.</i></p>
		  <button type="button" onclick="contact.php">CONTACT</button>
		</div>
	    <div class="col">
		  <div class="card card1">
		    <h5>Deluxe</h5>
		  </div>
		  <div class="card card2">
		    <h5>Family</h5>
		  </div>
		  <div class="card card3">
		    <h5>Suite</h5>
		  </div>
		  <div class="card card4">
		    <h5>Cabana</h5>
		  </div>
		
		</div>
	  </div>
    </div>

</body>
</html>