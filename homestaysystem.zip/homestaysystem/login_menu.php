<!DOCTYPE html>
<html>
<head>
   <title>login menu</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   <link rel="stylesheet" type="text/css" href="loginstyle.css">
</head>
<body>
    <label>
	<input type="checkbox">
	<div class="toggle">
	 <span class="top_line common"></span>
	 <span class="middle_line common"></span>
	 <span class="bottom_line common"></span>
	</div>
	 
	 <div class="slide">
	  <h1>MENU</h1>
	  <ul>
	   <li><a href="#"><i class="fas fa-user"></i>CUSTOMER</a></li> 
	   <li><a href="staff/loginstaff.php"><i class="fas fa-user"></i>STAFF</a></li>
	   <li><a href="admin/loginadmin.php"><i class="fas fa-user"></i>ADMIN</a></li>
	  </ul>
	 </div>
	</label>

   
   
 </body>
 </html>