<?php
include './db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['uname'];  // Updated to $_POST['uname']
  $password = $_POST['password'];    // Updated to $_POST['password']

  $query = "SELECT * FROM staff WHERE username = '$username' AND password = '$password'";
  $result = mysqli_query($connection, $query);

  if ($result->num_rows > 0) {
    // Login successful, redirect to a success page
    header("Location: staff/searchschedule.php");
    exit();
  } else {
    // Invalid login
    echo "<script>
      alert('You are not our staff!');
      window.location.href = 'loginstaff.php';
    </script>";
  }
}
?>
