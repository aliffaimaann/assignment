<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #f2f2f2;
  margin: 0;
  padding: 0;
}

.navbar {
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 80px;
  background: #000;
  color: #fff;
  font-size: 24px;
  padding: 0 20px;
}

.navbar-text img {
  width: 85px;
  height: 95px;
  margin-right: 45px;
}

.dropdown {
  margin-right: 20px;
}

.dropbtn {
  background-color: black;
  color: white;
  padding: 10px 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  display: flex;
  align-items: center;
}

.dropbtn i {
  margin-right: 5px;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
  right: 0;
}

.dropdown-content a {
  color: #fff;
  padding: 12px 16px;
  font-size: 14px;
  text-decoration: none;
  display: block;
  background-color: #333;
}

.dropdown-content a:hover {
  color: green;
  background-color: #03f40f;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.container {
  max-width: 100%;
  width: 400px;
  margin: 0 auto;
  padding: 20px;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.container h2 {
  text-align: center;
  margin-bottom: 20px;
}

.container img.avatar {
  display: block;
  margin: 0 auto 12px;
  width: 120px;
  height: 120px;
  border-radius: 50%;
}

.container label {
  font-weight: bold;
}

.container input[type="text"],
.container input[type="password"] {
  width: 100%;
  padding: 12px;
  margin-bottom: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

.container button {
  color: white;
  padding: 14px 20px;
  margin-top: 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  width: 49%;
}

.container button[type="submit"] {
  background-color: #6F0A2C; /* Updated back button color */
}

.container button[type="button"] {
  background-color: #4E3EDC; /* Updated done button color */
}

.container button:hover {
  opacity: 0.8;
}

.container .cancelbtn {
  background-color: #f44336;
}

.container .remember {
  float: left;
  margin-top: 8px;
}

.container .forgot {
  float: right;
  margin-top: 8px;
}

.container::after {
  content: "";
  display: table;
  clear: both;
}

.container .buttons {
  text-align: right; /* Align buttons to the right */
}

@media screen and (max-width: 400px) {
  .container {
    width: 90%;
    max-width: 400px;
    padding: 10px;
  }
}
</style>
</head>

<body>

<nav class="navbar">
  <div class="navbar-text">
    <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
  </div>
  <div class="dropdown">
    <button class="dropbtn">Staff</button>
    <div class="dropdown-content">
      <a href="logout.php">Log Out</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2>Staff Work Schedule</h2>

  <div class="imgcontainer">
    <img src="img/profile.png" alt="Avatar" class="avatar">
  </div>

  <form action="viewroomdetails.php" method="post">

    <div>
      <label for="uname">Username</label>
      <input type="text" placeholder="Enter Username" name="uname" required>

      <label for="sID">Schedule ID</label>
      <input type="text" placeholder="Enter Schedule ID" name="sID" required>

      <label for="rCode">Room Code</label>
      <input type="text" placeholder="Enter Room Code" name="rCode" required>

      <label for="sTime">Schedule Time</label>
      <input type="text" placeholder="Enter Schedule Time" name="sTime" required>

      <div class="buttons">
        <button type="submit">BACK</button>

        <button type="button" onclick="callbackFunction()">DONE</button> <!-- New button with onclick attribute -->
      </div>
    </div>
  </form>
</div>

<script>
  function callbackFunction() {
    // Perform desired callback actions here
    alert('Callback button clicked!');
  }
</script>

</body>
</html>
