<?php
// Include db.php file
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve file data
    $file = $_FILES['arquivo'];

    // Check if a file is selected
    if ($file['error'] === UPLOAD_ERR_OK) {
        // Get file information
        $fileName = $file['name'];
        $fileTmpPath = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileType = $file['type'];

        // Specify the target directory where you want to store the uploaded images
        $targetDir = 'uploads/';
        // Generate a unique filename to avoid conflicts
        $targetFileName = uniqid() . '_' . $fileName;
        $targetFilePath = $targetDir . $targetFileName;

        // Check if the file is a valid image
        $validImageTypes = ['jpg', 'jpeg', 'png', 'gif']; // Add more valid image types if needed
        $fileExtension = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        if (in_array($fileExtension, $validImageTypes)) {
            // Move the uploaded image to the target directory
            if (move_uploaded_file($fileTmpPath, $targetFilePath)) {
                // Image uploaded successfully, proceed with updating the room record in the database

                // Retrieve other form data
                $roomCode = $_POST['roomCode'];

                // Sanitize input values
                $roomCode = mysqli_real_escape_string($connection, $roomCode);
                $targetFilePath = mysqli_real_escape_string($connection, $targetFilePath);

                // Update the room record with the uploaded image path
                $query = "UPDATE room SET RoomImage = '$targetFilePath' WHERE RoomCode = '$roomCode'";
                $result = mysqli_query($connection, $query);

                // Check if the query execution was successful
                if ($result) {
                    // Redirect back to the room management page with a success message
                    header("Location: roomsection.php?message=Image uploaded successfully");
                    exit();
                } else {
                    // Error in executing the query
                    echo 'Error: ' . mysqli_error($connection);
                }
            } else {
                echo 'Error moving uploaded file.';
            }
        } else {
            echo 'Invalid image file type. Only JPG, JPEG, PNG, and GIF files are allowed.';
        }
    } else {
        echo 'Error uploading file: ' . $file['error'];
    }
}

// Close the database connection
mysqli_close($connection);
?>


<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>

    .navbar {
        position: relative;
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 70px;
        background-image: linear-gradient(to right, #000, #3533CD);
        color: #fff;
        font-size: 24px;
        padding: 0 20px;
    }

    .navbar-text img {
        width: 85px;
        height: 95px;
        margin-right: 45px;
    }

    .dropdown {
        margin-right: 20px;
    }

    .dropbtn {
        background-color: black;
        color: white;
        padding: 10px 16px;
        font-size: 16px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        display: flex;
        align-items: center;
    }

    .dropbtn i {
        margin-right: 5px;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
        right: 0;
    }

    .dropdown-content a {
        color: #fff;
        padding: 12px 16px;
        font-size: 14px;
        text-decoration: none;
        display: block;
        background-color: #333;
    }

    .dropdown-content a:hover {
        color: green;
        background-color: #03f40f;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dashboard {
        display: flex;
        min-height: 100vh;
    }

    .sidebar {
        width: 200px;
        background-color: #031159;
        color: #fff;
        padding: 25px;
    }

    .sidebar h1 {
        font-size: 24px;
        margin-bottom: 20px;
    }

    .sidebar ul {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .sidebar li {
        margin-bottom: 10px;
    }

    .sidebar a {
        color: #fff;
        text-decoration: none;
        transition: color 0.3s, background-color 0.3s;
    }

    .sidebar a:hover {
        color: #000;
        background-color: #fff;
    }

    .sidebar a.active {
        color: #000;
        background-color: #fff;
    }

    .content {
        flex: 1;
        padding: 20px;
        background-color: #f2f2f2;
    }

    .content h2 {
        font-size: 24px;
        margin-bottom: 20px;
    }

    .content p {
        margin-bottom: 10px;
    }

    .profile-sidebar {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
    }

    .profile-userpic img {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        margin-right: 10px;
    }

    .profile-usertitle {
        display: flex;
        flex-direction: column;
    }

    .profile-usertitle-name {
        font-weight: bold;
        font-size: 16px;
    }

    .profile-usertitle-status {
        font-size: 14px;
    }

    .profile-usertitle .indicator {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        display: inline-block;
        margin-right: 5px;
    }

    .label-success {
        background-color: green;
    }

    .divider {
        margin-bottom: 20px;
        border-bottom: 1px solid #fff;
    }

    .sidebar-image {
        background-image: url("img/user.png");
        background-size: cover;
        background-position: center;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        margin-bottom: 20px;
        margin-right: 10px;
        float: left;
    }

    .sidebar-heading {
        font-size: 24px;
        margin-bottom: 20px;
    }

    .panel-widget {
        text-align: center;
        padding: 20px;
    }

    .container {
        max-width: 300px;
        margin: 0 auto;
        padding: 20px;
        background-color: #13121269;
        border-radius: 5px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    label {
        font-weight: bold;
        display: block;
        margin-bottom: 10px;
    }

    .inpdddut[type="file"] {
        padding: 10px;
        margin-bottom: 20px;
        border: none;
        background-color: #1aa3bb;
        border-radius: 5px;
        width: 100%;
        cursor: pointer;
    }

    .inpdddut[type="submit"] {
        padding: 10px 20px;
        background-color: #008CBA;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .inpdddut[type="submit"]:hover {
        background-color: #006F8F;
    }
                
 
    </style>
</head>

<body>
<nav class="navbar">
        <div class="navbar-text">
            <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
        </div>
        <div class="dropdown">
            <button class="dropbtn">Staff</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <div class="sidebar">
            <div class="profile-sidebar">
                <div class="sidebar-image"></div>
                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">HR Staff</div>
                    <div class="profile-usertitle-status"><span class="indicator label-success"></span>Leader</div>
                </div>
            </div>
            <div class="divider"></div>
            <ul class="nav menu">
                <li>
                    <a href="searchschedule.php"><h1>Staff Duty</h1></a>
                </li>
                <li>
                    <a href="roomsection.php"><h1>Room Section</h1></a>
                </li>
                <li>
                    <a href="bookinginf.php"><h1>Booking Information</h1></a>
                </li>
                <li>
                    <a href="viewpayment.php"><h1>Payment Details</h1></a>
                </li>
            </ul>
        </div>

        <div class="container">
    <form method="POST" enctype="multipart/form-data" action="updateimage.php">
        <input type="hidden" name="roomCode" value="<?php echo $_GET['roomCode']; ?>">       
        <label for="arquivo">Choose a file:</label>
        <input accept=".jpg, .jpeg, .png, .gif" class="inpdddut" name="arquivo" id="arquivo" type="file">
        <input value="Update" type="submit" class="inpdddut">
    </form>
</div>
