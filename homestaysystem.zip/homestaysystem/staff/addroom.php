<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .navbar {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
            background-image: linear-gradient(to right, #000,#3533CD);
            color: #fff;
            font-size: 24px;
            padding: 0 20px;
        }

        .navbar-text img {
            width: 85px;
            height: 95px;
            margin-right: 45px;
        }

        .dropdown {
            margin-right: 20px;
        }

        .dropbtn {
            background-color: black;
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            display: flex;
            align-items: center;
        }

        .dropbtn i {
            margin-right: 5px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            right: 0;
        }

        .dropdown-content a {
            color: #fff;
            padding: 12px 16px;
            font-size: 14px;
            text-decoration: none;
            display: block;
            background-color: #333;
        }

        .dropdown-content a:hover {
            color: green;
            background-color: #03f40f;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 200px;
			background-color: #031159;
            color: #fff;
            padding: 25px;
            
        }

        .sidebar h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s, background-color 0.3s;
        }

        .sidebar a:hover {
            color: #000;
            background-color: #fff;
        }

        .sidebar a.active {
            color: #000;
            background-color: #fff;
        }

        .content {
            flex: 1;
            padding: 20px;
            background-color: #f2f2f2;
        }

        .content h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .content p {
            margin-bottom: 10px;
        }

        .profile-sidebar {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .profile-userpic img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile-usertitle {
            display: flex;
            flex-direction: column;
        }

        .profile-usertitle-name {
            font-weight: bold;
            font-size: 16px;
        }

        .profile-usertitle-status {
            font-size: 14px;
        }

        .profile-usertitle .indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }

        .label-success {
            background-color: green;
        }

        .divider {
            margin-bottom: 20px;
            border-bottom: 1px solid #fff;
        }

        .sidebar-image {
            background-image: url("img/user.png");
            background-size: cover;
            background-position: center;
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
            margin-right: 10px;
            float: left;
        }

        .sidebar-heading {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .staff {
        color: #000;
        text-transform: uppercase;
        letter-spacing: 2px;
        display: block;
        font-weight: bold;
        font-size: x-large;
        margin-top: 1.5em;
        }

        .card {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 250px;
        width: 650px;
        flex-direction: column;
        margin: 90px; /* Add this line to center the card */
        margin-top: -100px; /* Adjust the margin-top value as needed */\
        gap: 35px;
        border-radius: 15px;
        background: #e3e3e3;
        box-shadow: 16px 16px 32px #c8c8c8,
                -16px -16px 32px #fefefe;
        border-radius: 8px;
        }

        .container {
        display: flex;
        margin-left: 400px;
        justify-content: center;
        align-items: center;
        }

        .inputBox,
        .inputBox1 {
        position: relative;
        width: 250px;
        }

        .inputBox input,
        .inputBox1 input {
        width: 100%;
        padding: 10px;
        outline: none;
        border: none;
        color: #000;
        font-size: 1em;
        background: transparent;
        border-left: 2px solid #000;
        border-bottom: 2px solid #000;
        transition: 0.1s;
        border-bottom-left-radius: 8px;
        }

        .inputBox span,
        .inputBox1 span {
        margin-top: 5px;
        position: absolute;
        left: 0;
        transform: translateY(-4px);
        margin-left: 10px;
        padding: 10px;
        pointer-events: none;
        font-size: 12px;
        color: #000;
        text-transform: uppercase;
        transition: 0.5s;
        letter-spacing: 3px;
        border-radius: 8px;
        }

        .inputBox input:valid~span,
        .inputBox input:focus~span {
        transform: translateX(113px) translateY(-15px);
        font-size: 0.8em;
        padding: 5px 10px;
        background: #000;
        letter-spacing: 0.2em;
        color: #fff;
        border: 2px;
        }

        .inputBox1 input:valid~span,
        .inputBox1 input:focus~span {
        transform: translateX(156px) translateY(-15px);
        font-size: 0.8em;
        padding: 5px 10px;
        background: #000;
        letter-spacing: 0.2em;
        color: #fff;
        border: 2px;
        }

        .inputBox input:valid,
        .inputBox input:focus,
        .inputBox1 input:valid,
        .inputBox1 input:focus {
        border: 2px solid #000;
        border-radius: 8px;
        }

        .enter {
        height: 45px;
        width: 100px;
        border-radius: 5px;
        border: 2px solid #000;
        cursor: pointer;
        background-color: transparent;
        transition: 0.5s;
        text-transform: uppercase;
        font-size: 10px;
        letter-spacing: 2px;
        margin-bottom: 3em;
        }

        .enter:hover {
        background-color: rgb(0, 0, 0);
        color: white;
        }

        .button-container {
        display: flex;
        justify-content: space-between;
        margin-top: 1.5em;
        gap: 15px
        }

</style>

</head>
<body>
    <nav class="navbar">
        <div class="navbar-text">
            <img src="img/logo.png" alt="Logo" style="width: 85px; height: 90px; margin-right: 45px;">
        </div>
        <div class="dropdown">
            <button class="dropbtn">Staff</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <div class="dashboard">
        <div class="sidebar">
            <div class="profile-sidebar">
                <div class="sidebar-image"></div>
                <div class="profile-usertitle">
                    <div class="profile-usertitle-name">HR Staff</div>
                    <div class="profile-usertitle-status"><span class="indicator label-success"></span>Leader</div>
                </div>
            </div>
            <div class="divider"></div>
            <ul class="nav menu">
                <li>
                    <a href="searchschedule.php"><h1>Staff Duty</h1></a>
                </li>
                <li>
                    <a href="roomsection.php"><h1>Room Section</h1></a>
                </li>
                <li>
                    <a href="roomsection.php"><h1>Booking Information</h1></a>
                </li>
                <li>
                    <a href="viewpayment.php"><h1>Payment Details</h1></a>
                </li>
            </ul>
        </div>

        <div class="container">
    <div class="card">
        <a class="staff">NEW ROOM</a>
        <form action="addroom_process.php" method="POST">
            <div class="inputBox">
                <input type="text" name="roomCode" required="required">
                <span class="user">ROOM CODE</span>
            </div>
            
            <div class="inputBox">
                <input type="text" name="roomName" required="required">
                <span class="user">ROOM NAME</span>
            </div>

            <div class="inputBox">
                <input type="text" name="roomPrice" required="required">
                <span>ROOM PRICE</span>
            </div>

            <div class="inputBox">
                <input type="text" name="roomType" required="required">
                <span>ROOM TYPE</span>
            </div>

            <div class="inputBox">
                <input type="text" name="roomFacilities" required="required">
                <span>ROOM FACILITIES CHOSEN</span>
            </div>

            <div class="button-container">
                <button type="submit" class="enter">ADD</button>
                <button class="enter" onclick="goBack()">CANCEL</button>
            </div>
        </form>
    </div>
</div>


<script>
        function goBack() {
            window.location.href = "roomsection.php";
        }

</script>

