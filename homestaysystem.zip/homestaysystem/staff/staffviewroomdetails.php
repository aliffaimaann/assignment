<?php
include './db.php';

$roomcode = $_POST['RoomCode'];

// Connection to the server and datbase
$dbc = mysqli_connect ("localhost","root","","homestay");

if (mysqli_connect_errno())
	
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
	
// SQL statement to insert data from form into table staff
$sql="insert into `staff`(`RoomCode`) values ('$roomcode',)";
$results= mysqli_query($dbc,$sql);

if ($results)
{
mysqli_commit($dbc);
//display message box Record Been Added
print '<script>alert("Record Had Been Added");</script>';
//go to frmcustomer.php page
print '<script>window.location.assign("staffviewroomdetails.php");</script>';
}
else
{ mysqli_rollback($dbc);
//display error message box
print '<script>alert("Data Is Invalid , No Record Been Added");</script>';
//go to frmcustomer.php page
print '<script>window.location.assign("staffviewroomdetails.php");</script>';
}
?>
	