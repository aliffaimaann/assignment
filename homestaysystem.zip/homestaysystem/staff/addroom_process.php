<?php
// Include db.php file
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $roomCode = $_POST['roomCode'];
    $roomName = $_POST['roomName'];
    $roomPrice = $_POST['roomPrice'];
    $roomType = $_POST['roomType'];
    $roomFacilities = $_POST['roomFacilities'];

    // Sanitize input values
    $roomCode = mysqli_real_escape_string($connection, $roomCode);
    $roomName = mysqli_real_escape_string($connection, $roomName);
    $roomPrice = mysqli_real_escape_string($connection, $roomPrice);
    $roomType = mysqli_real_escape_string($connection, $roomType);
    $roomFacilities = mysqli_real_escape_string($connection, $roomFacilities);

    // Insert new room into the database
    $query = "INSERT INTO room (RoomCode, RoomName, RoomPrice, RoomType, RoomFacilitiesChosen) VALUES ('$roomCode', '$roomName', '$roomPrice', '$roomType', '$roomFacilities')";
    $result = mysqli_query($connection, $query);

    // Check if the query execution was successful
    if ($result) {
        // Redirect back to the room management page with a success message
        header("Location: roomsection.php?message=Room added successfully");
        exit();
    } else {
        // Error in executing the query
        echo 'Error: ' . mysqli_error($connection);
    }
}

// Close the database connection
mysqli_close($connection);
?>
