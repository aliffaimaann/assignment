<html>
<head>
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-...your-sha512-hash..." crossorigin="anonymous" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css"/>

    <style>
         body {
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .navbar {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
            background: #000;
            color: #fff;
            font-size: 24px;
            padding: 0 20px;
        }

        .navbar-text img {
            width: 85px;
            height: 95px;
            margin-right: 45px;
        }

        .dropdown {
            margin-right: 20px;
        }

        .dropbtn {
            background-color: black;
            color: white;
            padding: 10px 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            display: flex;
            align-items: center;
        }

        .dropbtn i {
            margin-right: 5px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            right: 0;
        }

        .dropdown-content a {
            color: #fff;
            padding: 12px 16px;
            font-size: 14px;
            text-decoration: none;
            display: block;
            background-color: #333;
        }

        .dropdown-content a:hover {
            color: green;
            background-color: #03f40f;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }
        
        .login-card {
          width: 300px;
          margin: 0 auto;
          padding: 40px;
          margin-top: 150px;
          border: 1px solid #ccc;
          border-radius: 10px;
          background-color: #e8e8e8;
          box-shadow: 2px 2px 10px #ccc;
        }

        .card-header {
          text-align: center;
          margin-bottom: 25px
        }

        .card-header .log {
          margin: 0;
          font-size: 24px;
          color: black;
        }

        .card-header .log i {
          margin-right: 5px;
        }

        .form-group {
          margin-bottom: 15px;
        }

        label {
          font-size: 18px;
          margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
          width: 100%;
          padding: 12px 20px;
          font-size: 16px;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
          transition: 0.5s;
        }

        input[type="submit"] {
          width: 100%;
          background-color: #333;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }

        input[type="submit"]:hover {
          background-color: #ccc;
          color: black;
        }

        
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-text">Homestay Online Reservation</div>
        
        <div class="dropdown">
            <button class="dropbtn">Staff</button>
            <div class="dropdown-content">
                <a href="logout.php">Log Out</a>
            </div>
        </div>
    </nav>

    <!-- Login form with PHP integration -->
<div class="login-card">
  <div class="card-header">
    <div class="log">
      <i class="fas fa-user"></i> Staff Login</div>
  </div>
  <form action="loginprocess.php" method="POST">
    <div class="form-group">
      <label for="username">Username:</label>
      <input required="" placeholder="Insert correct username" name="uname" id="uname" type="text">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input required="" placeholder="Password" name="password" id="psw" type="password">
    </div>
    <div class="form-group">
      <input value="Login" type="submit">
    </div>
  </form>
</div>
