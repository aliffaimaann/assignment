<?php
// Include db.php file
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the updated room details from the form
    $roomCode = $_POST['roomCode'];
    $roomName = $_POST['roomName'];
    $roomPrice = $_POST['roomPrice'];
    $roomType = $_POST['roomType'];
    $roomFacilities = $_POST['roomFacilities'];

    // Update the room details in the database
    $query = "UPDATE room SET
              RoomName = '$roomName',
              RoomPrice = '$roomPrice',
              RoomType = '$roomType',
              RoomFacilitiesChosen = '$roomFacilities'
              WHERE RoomCode = '$roomCode'";

    // Execute the query
    $result = mysqli_query($connection, $query);

    // Check if the query execution was successful
    if ($result) {
        // Redirect back to the room management page with success message
        echo "<script>
            alert('Room details updated successfully!');
            window.location.href = 'roomsection.php';
        </script>";
        exit();
    } else {
        // Error in executing the query
        echo 'Error: ' . mysqli_error($connection);
    }
}

// Close the database connection
mysqli_close($connection);
?>