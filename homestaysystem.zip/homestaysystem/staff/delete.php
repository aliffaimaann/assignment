<?php
// Include db.php file
include 'db.php';

// Check if the form is submitted and the room code is provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['roomCode'])) {
    // Retrieve the room code from the form
    $roomCode = $_POST['roomCode'];

    // Delete the room record from the database
    $query = "DELETE FROM room WHERE RoomCode = '$roomCode'";

    // Execute the query
    $result = mysqli_query($connection, $query);

    // Check if the query execution was successful
    if ($result) {
        // Redirect back to the room management page with a success message
        echo "<script>
                alert('Room record deleted successfully');
                window.location.href = 'roomsection.php';
              </script>";
        exit();
    } else {
        // Error in executing the query
        echo 'Error: ' . mysqli_error($connection);
    }
}

// Close the database connection
mysqli_close($connection);
?>
