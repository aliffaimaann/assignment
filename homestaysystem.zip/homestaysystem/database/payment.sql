-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2023 at 08:18 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homestay`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` int(4) NOT NULL,
  `PaymentDeposit` decimal(10,2) NOT NULL,
  `PaymentFull` decimal(10,2) NOT NULL,
  `PaymentTransaction` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `PaymentDeposit`, `PaymentFull`, `PaymentTransaction`) VALUES
(1502, 450.00, 1600.00, 'TG11 7100501'),
(1550, 450.00, 800.00, 'TH45 7003401'),
(1789, 450.00, 1200.00, 'TM34 7113231'),
(1878, 450.00, 1600.00, 'FO53 2F1323'),
(3262, 150.00, 300.00, 'FKL5 7434511'),
(3330, 150.00, 300.00, 'LK00 7005104'),
(3352, 150.00, 300.00, 'LL00 7004104'),
(3435, 150.00, 300.00, 'F005 7405114'),
(4533, 350.00, 1800.00, 'EFO1 9277182'),
(6566, 250.00, 1800.00, 'CFO1 9207182'),
(6800, 450.00, 1800.00, 'MD01 3207102'),
(6873, 250.00, 900.00, 'KM11 9207102'),
(7678, 350.00, 700.00, 'MM05 7204104'),
(7719, 450.00, 1400.00, 'LK89 9204104'),
(7790, 450.00, 1050.00, 'RL14 8207104'),
(7875, 450.00, 1050.00, 'MK00 9207104'),
(9689, 200.00, 500.00, 'FEL3 7230511'),
(9965, 450.00, 1250.00, 'AM23 7000501'),
(9976, 450.00, 1000.00, 'TR20 7110501'),
(9990, 200.00, 500.00, 'FL23 7000511');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `PaymentID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9991;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
