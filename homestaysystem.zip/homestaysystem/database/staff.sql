-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2023 at 10:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homestay`
--

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` int(2) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `StaffName` varchar(50) NOT NULL,
  `StaffPhNum` int(10) NOT NULL,
  `StaffAddress` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `username`, `password`, `StaffName`, `StaffPhNum`, `StaffAddress`) VALUES
(1, 'hafiz', 'mhafiz2', 'MUHAMMAD HAFIZ BIN SALEH', 169700891, 'Jalan S2 A40, 70200, Seremban '),
(2, 'insyira', 'ctinsyi3', 'SITI INSYIRA BINTI AZIM', 126544900, 'Jalan Dato Klana, 70200, Seremban'),
(3, 'amirul', 'aarifjzli', 'AMIRUL ARIF BIN JAZLI', 146309182, 'Kg Lubok, Mulong, Kota Bharu,16450, Kelantan'),
(4, 'aulia', 'aulfauzi', 'AULIA BINTI FAUZI', 16352363, 'Taman Rembia Cemerlang, Rembia, 78000, Melaka'),
(5, 'iqhbal', 'iqhthefish', 'IQHBAL AL\'FAJR', 16352363, 'Lot 5362, Taman Bukit Tebu,Tanah Merah, Kelantan'),
(6, 'mastura', 'mas45#', 'MASTURA BINTI AZLIM', 179097342, '83, Jalan Medang, Bangsar, 59000, Kuala Lumpur'),
(7, 'johari', 'jo35@', 'JOHARI BIN TALIL', 188717983, 'Semabok ,Melaka Tengah, 75050, Melaka'),
(8, 'saniy', 'san67#', 'SANIY BIN AZLIM', 179097344, 'Jalan Dahlia, Melaka Tengah, 75250, Melaka'),
(9, 'aidil', 'mohd22#', 'MOHAMED AIDIL BIN MOHAMED AZLIM', 16352363, 'Taman Permatang Pasir Permai, 75050, Melaka'),
(10, 'sufian', '90sufian', 'SUFIAN LIM XI ZHAO BIN AZLIM', 126544901, 'Jalan Nusa Intan 6/7, Senawang, 70200 ,Seremban\r\n'),
(11, 'dahlia', '11dahlia@', 'DAHLIA HUSNA BINTI KARIM', 194913226, 'Bandar Sri Sendayan, 70200, Seremban'),
(12, 'ayuni', 'shafyun3', 'SHAFI AYUNI BINTI OTHMAN', 121225036, 'Bandar Baru Nilai, 71800, Nilai'),
(13, 'akmar', 'mar34', 'AKMAR BINTI RAUF', 136447365, 'Persiaran Utama S2/3, 70200, Seremban'),
(14, 'iman', 'n@iman', 'NURUL IMAN BINTI ROZI', 120959064, 'Jalan Indah 2/8, Taman Jade Hill, 73000, Tampin'),
(15, 'ainaa', 'sha55#', 'SHA AINAA BINTI RAIF', 196642123, 'Setapak, 53000, Kuala Lumpur'),
(16, 'raid', 'rhkm#', 'RAID HAKIM BIN AZIZI', 126544904, 'Desa Setapak, 53300, Kuala Lumpur'),
(17, 'rahimi', 'r@himi3', 'RAHIMI BIN ALI', 188717977, 'Taman Tehel Indah, Hang Tuah Jaya, 75450, Melaka'),
(18, 'firdaus', 'fird@us2', 'AHMAD FIRDAUS BIN DAHLAN', 137712745, 'Jalan Idaman , Taman Kelubi Idaman, 77000, Melaka'),
(19, 'amir', 'uwaisrt2', 'AMIR UWAIS BIN RAHMAT', 169342334, 'Jalan MP 8, Taman Merdeka Permai, 75350, Melaka'),
(20, 'aniqh', '@niq11', 'ANIQ HAKIMIE BIN SAIDI', 146305774, 'Jalan Syahbandar, Kota Laksamana, 75200, Melaka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `StaffID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
