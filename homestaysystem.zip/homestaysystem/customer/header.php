<html>
<style>
body { 
font-family: Fantasy
color: black;
margin: 0;
padding: 0;
}

body {
  background-color: #ADD8E6;
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: 100% 100%;
}
</style>
<body background= "blue.gif" align="center">
<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
<ul class = "nav navbar-nav pull-right ">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class = "glyphicon glyphicon-user"></i></a>
					<ul class="dropdown-menu">
						<li><a href="logout.php"><i class = "glyphicon glyphicon-off"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
<div class = "container-fluid">	
		<ul class = "nav nav-pills">
			<a href = "home.php">HOME</a>
			<a href = "login.php">LOGIN</a>
			<a href = "contact.php">CONTACT</a>			
		</ul>	
</div>
</body>
</html>