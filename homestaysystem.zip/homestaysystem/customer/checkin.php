<?php       
$in = $_POST['check-in'];  
$out = $_POST['check-out'];  

$dbc = mysqli_connect("localhost","root","","homestay");
if (mysqli_connect_errno())
    {
		echo "Failed to connect to MySQL:".mysqli_connect_error();
	}
      
//to prevent from mysqli injection  
$in = stripcslashes($in);  
$out = stripcslashes($out);  
$username = mysqli_real_escape_string($con, $in);
$password = mysqli_real_escape_string($con, $out);  
      
$sql = "select *from room where RoomCin = '$in' and RoomCout = '$out'";  
$result = mysqli_query($con, $sql);  
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
if($result)  
    {  
		mysqli_commit($dbc);
        Print '<script>alert("Date Available.");</script>';  
    }  
    else
	{  
		mysqli_rollback($dbc);
        Print'<script>alert("Date Not Available.");</script>';  
    }     
?>  