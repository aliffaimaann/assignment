<?php
include 'db.php';

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (isset($_POST['search'])) {
    $searchTerm = $_POST['searchTerm'];
    $results = array();

    // Prepare and execute the search query
    $sql = "SELECT customer.CustID, customer.CustName, booking.BookingID, booking.RoomCode, booking.PaymentID, booking.BookingForm
            FROM customer
            LEFT JOIN booking ON customer.CustID = booking.CustID
            WHERE customer.CustID = '$searchTerm'";
    $result = $connection->query($sql);

    // Fetch the search results
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
    }
}

// Close the database connection
$connection->close();
?>

<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="bookingstyle.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
</head>

<body>
<div class="dashboard">
<div class="menu-btn">
     <i class="fas fa-bars"></i>
   </div>
   <div class="side-bar">
     <div class="close-btn">
       <i class="fas fa-times"></i>
     </div>
     <div class="menu">
       <div class="item">
         <a class="sub-btn"><i class="fas fa-table"></i>Menu<i class="fas fa-angle-right dropdown"></i></a>
         <div class="sub-menu">
           <a href="bookingpref.php" class="sub-item">Booking</a>
           <a href="bookingdetails.php" class="sub-item">Booking Details</a>
         </div>
       </div>
       <div class="item">
         <a class="sub-btn"><i class="fas fa-cogs"></i>More<i class="fas fa-angle-right dropdown"></i></a>
         <div class="sub-menu">
           <a href="logout.php" class="sub-item">Log Out</a>
         </div>
       </div>
       <div class="item"><a href="about.php"><i class="fas fa-info-circle"></i>About</a></div>
     </div>
   </div>
   <section class="main">
   </section>

<div class="content">
            <div class="panel-container">
                
                <form method="POST" action="bookingdetails.php" class="search-form">
                    <input placeholder="Insert Customer ID" type="text" name="searchTerm" class="input">
                    <input type="submit" name="search" value="Search">
                </form>

                <?php if (isset($_POST['search'])): ?>
                        <?php if (count($results) > 0): ?>
                            <h3>Booking Details:</h3>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Customer ID</th>
                                            <th>Customer Name</th>
                                            <th>Booking ID</th>
                                            <th>Room Code</th>
                                            <th>Payment ID</th>
											<th>Booking Form</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($results as $result): ?>
                                            <tr>
                                                <td><?php echo $result['CustID'] ?? ''; ?></td>
                                                <td><?php echo $result['CustName'] ?? ''; ?></td>
												<td><?php echo $result['BookingID'] ?? ''; ?></td>
                                                <td><?php echo $result['RoomCode'] ?? ''; ?></td>
                                                <td><?php echo $result['PaymentID'] ?? ''; ?></td>
                                                <td><?php echo $result['BookingForm'] ?? ''; ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p>No results found.</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <!-- Existing code to display the table of all staff members -->
                    <?php endif; ?>



            </div>
        </div>
    </div>
	
	<script type="text/javascript">
   $(document).ready(function(){
     //jquery for toggle sub menus
     $('.sub-btn').click(function(){
       $(this).next('.sub-menu').slideToggle();
       $(this).find('.dropdown').toggleClass('rotate');
     });

     //jquery for expand and collapse the sidebar
     $('.menu-btn').click(function(){
       $('.side-bar').addClass('active');
       $('.menu-btn').css("visibility", "hidden");
     });

     $('.close-btn').click(function(){
       $('.side-bar').removeClass('active');
       $('.menu-btn').css("visibility", "visible");
     });
   });
   </script>

    <script src="js/bootstrap.min.js"></script>
</body>
</html>