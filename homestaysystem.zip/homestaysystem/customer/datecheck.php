<html>
<head>
<title>Homestay System</title>
<!--insert style.css file inside index.html-->  
<link rel = "stylesheet" type = "text/css" href = "style.css">
<style>
body{   
    background: #eee;  
}  
#frm{  
    border: solid gray 1px;  
    width:25%;  
    border-radius: 2px;  
    margin: 120px auto;  
    background: white;  
    padding: 50px;  
}  
#btn{  
    color: #fff;  
    background: #337ab7;  
    padding: 7px;  
    margin-left: 70%;  
}  
</style>
</head>
<body>
    <div id = "frm">
		<form class="homestay-reservation-form" method="post" action="">
			<h1><i class="far fa-calendar-alt"></i>Check-in & Check-out Date</h1>
		
				<!-- Input Elements -->
				<p>  
                <label> Check-In: </label>  
                <input type = "date"  name  = "check-in" />  
			</p>  
            <p>  
                <label> Check-Out: </label>  
                <input type = "date"  name  = "check-out" />
			</p>  
            <p>      
                <input type =  "submit"  id = "btn"  value = "Submit"  a href="bookingpref.php"/>  
            </p> 
		</form>
	</div>
</body>
</html>