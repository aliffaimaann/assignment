<?php
// Include the database connection file
include './db.php';

// SQL query to join three tables
$sql = "SELECT *
        FROM room
        INNER JOIN customer ON room.column1 = customer.column2
        INNER JOIN payment ON customer.column3 = payment.column4";

// Execute the query
$result = $mysqli->query($sql);

// Check if the query was successful
if ($result) {
    // Fetch the data and store it in variables
    $row = $result->fetch_assoc();
    $RoomCin = $row['RoomCin'];
    $RoomCout = $row['RoomCout'];
    $CustName = $row['CustName'];
    $CustID = $row['CustID'];
    $CustPNum = $row['CustPNum'];
    $PaymentTransaction = $row['PaymentTransaction'];
    $PaymentFull = $row['PaymentFull'];

    // Free the result set
    $result->free();
} else {
    // Query execution failed
    echo "Error: " . $mysqli->error;
}

// Close the database connection
$mysqli->close();
?>
