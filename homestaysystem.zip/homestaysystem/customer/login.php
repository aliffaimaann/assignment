<html>  
<head>  
<title>Homestay System</title>  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel = "stylesheet" type = "text/css" href = "indexstyle.css">
<style>

.login-card {
          width: 300px;
          margin: 0 auto;
          padding: 40px;
          margin-top: 100px;
          border: 1px solid #ccc;
          border-radius: 10px;
          background-color: #A78C6F;
          box-shadow: 2px 2px 10px #ccc;
        }

        .card-header {
          text-align: center;
          margin-bottom: 25px
        }

        .card-header .log {
          margin: 0;
          font-size: 24px;
          color: black;
        }

        .card-header .log i {
          margin-right: 5px;
        }

        .form-group {
          margin-bottom: 15px;
        }

        label {
          font-size: 18px;
          margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
          width: 100%;
          padding: 12px 20px;
          font-size: 16px;
          border: 1px solid #ccc;
          border-radius: 4px;
          box-sizing: border-box;
          transition: 0.5s;
        }

        input[type="submit"] {
          width: 100%;
          background-color: #333;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }

        input[type="submit"]:hover {
          background-color: #E4CDE0;
          color: black;
        }
		
		.btn {
			background-color: #D3E9FB;
			border: none;
			color: black;
			padding: 12px 16px;
			font-size: 16px;
			cursor: pointer;
			margin-left: 1100px;
		}

		/* Darker background on mouse-over */
		.btn:hover {
			background-color: Blue;
</style>
</head>  
<body> 
	<body style="background-color:#F5F6F8;font-family:-apple-system, BlinkMacSystemFont, 'segoe ui', roboto, oxygen, ubuntu, cantarell, 'fira sans', 'droid sans', 'helvetica neue', Arial, sans-serif;box-sizing:border-box;font-size:16px;">
		<div style="background-color:#fff;margin:30px;box-sizing:border-box;font-size:16px;">
		<h1 style="padding:40px;box-sizing:border-box;font-size:24px;color:#000000;background-color:#D3E9FB;margin:0;">Hotel Reservation
		<button class="btn">
		<i class="fa fa-home" onclick="location.href='mainmenu.php'"></i>
		</button></h1>
			<div style="box-sizing:border-box;padding:0 40px 20px;">
			
<!-- Login form with PHP integration -->
<div class="login-card">
  <div class="card-header">
    <div class="log">
      <i class="fas fa-user"></i>Login</div>
  </div>
  <form action="userlogin.php" method="POST">
    <div class="form-group">
      <label for="username">Username:</label>
      <input required="" placeholder="Username" name="username" id="username" type="text">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input required="" placeholder="Password" name="password" id="password" type="password">
    </div>
    <div class="form-group">
      <input value="Login" type="submit">
    </div>
	<p><a href="signin.php">REGISTER</a></p>
  </form>
</div>
    <!--validation for empty field-->   
    <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");
				 return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
</body>     
</html>  