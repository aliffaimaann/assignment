<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<style>
body{   
    background: #eee;  
}  
#frm{  
    border: solid gray 1px;  
    width:25%;  
    border-radius: 2px;  
    margin: 120px auto;  
    background: white;  
    padding: 50px;  
}  
#btn{  
    color: #fff;  
    background: #337ab7;  
    padding: 7px;  
    margin-left: 70%;  
}  
</style>
</head>
<body>
<?php
$username =$_GET['user'];
$dbc = mysqli_connect("localhost","root","","homestay");
if(mysqli_connect_errno())
  {
    echo "Failed to connect MySQL:".mysqli_connect_error();
  }
$sql ="select * from users where user ='$username'";
$result = mysqli_query($dbc,$sql);
if(false === $result)
    {
		echo mysqli_error();
	}
$row = mysqli_fetch_assoc($result)
?>
<form action="passup.php?fid=<?php echo $username;?>" method="post">
		<p>  
                <label> UserName: </label>  
                <input type = "text"  name  = "user" value='<?=$row['user'];?>'>  
		</p>
		<p>  
                <label> Password: </label>  
                <input type = "password"  name  = "pass" value='<?=$row['password'];?>'>
				
		</p>
		<p>     
                <input type =  "submit" id = "btn" value = "Update" onClick="return confirm('Are you sure?')">  
        </p> 
</form>
</body>
</html>	