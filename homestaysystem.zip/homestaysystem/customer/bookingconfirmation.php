<!DOCTYPE html>
<html>
<style>

.feed-form {
  margin-top: 36px;
  display: flex;
  flex-direction: column;
  width: 300px;
}

.feed-form input {
  height: 54px;
  border-radius: 5px;
  background: white;
  margin-bottom: 15px;
  border: none;
  padding: 0 20px;
  font-weight: 300;
  font-size: 14px;
  color: #4B4B4B;
}

.button_submit:hover, .feed-form input:hover {
  transform: scale(1.009);
  box-shadow: 0px 0px 3px 0px #212529;
}

.button_submit {
  width: 100%;
  height: 54px;
  font-size: 14px;
  color: white;
  background: red;
  border-radius: 5px;
  border: none;
  font-weight: 500;
  text-transform: uppercase;
}

</style>

<body>
<center>


<section class="section_form">
  <form id="homestay-reservation-form" class="feed-form" action="add_booking.php">
    <input name="CustID" required="" placeholder="CUSTOMER ID" type="text" size="20">
    <input name="CustName" required="" placeholder="NAME" type="text" size="50">
    <input name="CustAddress" required="" placeholder="ADDRESS" type="text" size="20">
	<input name="CustPNum" required="" placeholder="PHONE NUMBER" type="text" size="10">
    <button name = "bookingconfirmation" class="button_submit">SUBMIT</button>
	
	<?php require_once 'add_booking.php'?>
  </form>
</section>

</center>
</body>
</html>