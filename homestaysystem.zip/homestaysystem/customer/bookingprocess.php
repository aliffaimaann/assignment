<?php
include './db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $CustID = $_POST['CustID'];
    $RoomName = $_POST['RoomName'];
    $RoomType = $_POST['RoomType'];
    $RoomCin = $_POST['RoomCin'];
    $RoomCout = $_POST['RoomCout'];
    $RoomFacilitiesChosen = $_POST['RoomFacilitiesChosen'];

    // Generate a unique room code
    $roomCode = generateRoomCode($connection);

    $query = "INSERT INTO room (RoomCode, CustID, RoomName, RoomType, RoomCin, RoomCout, RoomFacilitiesChosen) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "sssssss", $roomCode, $CustID, $RoomName, $RoomType, $RoomCin, $RoomCout, $RoomFacilitiesChosen);
    
    if (mysqli_stmt_execute($stmt)) {
        // Insert successful, redirect to a success page
        header("Location: bookingnotification.php");
        exit();
    } else {
        // Insert failed
        $error_message = "Failed to insert data: " . mysqli_error($connection);
        echo "<script>alert('$error_message');</script>";
    }

    mysqli_stmt_close($stmt);
}

// Function to generate a unique room code
function generateRoomCode($connection)
{
    $prefix = 'B';
    $query = "SELECT MAX(RoomCode) AS maxCode FROM room";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    $maxCode = $row['maxCode'];

    if ($maxCode) {
        $newCode = $prefix . (intval(substr($maxCode, 1)) + 1);
    } else {
        $newCode = $prefix . '1';
    }

    return $newCode;
}
?>