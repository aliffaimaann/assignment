<html>
<head>
    <title>Homestay System</title>
	<link rel="stylesheet" href="indexstyle.css">
</head>
<body>
  <div class="banner">
  <div class="navbar">
    <img src="logo.png" class="logo">
	<ul>
	    <li><a href="index2.php">HOME</a></li>
		<li><a href="login.php">LOGIN</a></li>
		<li><a href="logout.php">LOGOUT</a></li>
		<li><a href="contact.php">CONTACT</a></li>
	</ul>
  </div>
  </div>
  
 </body>
 </html>