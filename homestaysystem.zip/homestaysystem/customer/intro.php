<!DOCTYPE html>
<html>
<head>
<title> INTRODUCTION </title>
</head>
<frameset cols="12% , *">
<frame name="menu" src="menu.php" noresize="0"> </frame>
<frameset rows="16%, *">
<frame name="header" src="header.php" noresize="0"> </frame>
<frame name="content" src="bookingconfirmation.php" noresize="0"> </frame>
</frameset>

<body background="background.gif" align="center">
<h1><mark class="curved-highlight"><i>INTRODUCTION</i></mark></h1>

</body>
</html>