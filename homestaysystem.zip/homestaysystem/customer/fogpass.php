<html>
<head>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<style>
body{   
    background: #eee;  
}  
#frm{  
    border: solid gray 1px;  
    width:25%;  
    border-radius: 2px;  
    margin: 120px auto;  
    background: white;  
    padding: 50px;  
}  
#btn{  
    color: #fff;  
    background: #337ab7;  
    padding: 7px;  
    margin-left: 70%;  
}  
</style>
</head>
<body>
<?php
$password = $_GET['pass'];
$dbc = mysqli_connect("localhost","root","","homestay");
if(mysqli_connect_errno())
  {
    echo "Failed to connect MySQL:".mysqli_connect_error();
  }