<html>
<head>
<link rel="stylesheet" type="text/css" href="style3.css">
</head>
<style>
body {
  background-color: #ADD8E6;
  background-repeat: no-repeat;
  background-attachment: fixed;  
  background-size: 100% 100%;
}
</style>
<body>
<nav>
<h2>MENU</h2>
<a href="bookingconfirmation.php" target="content"><h3>BOOKING</a><p>
<a href="bookingdetails.php" target="content">CHECK BOOKING</a><p>
</nav>
</body>
</html>