<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homestay Online Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="bookingprocess.php">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
    <link rel="stylesheet" type="text/css" href="custstyle.css">
    <style>

#frm{  
    border: solid gray 1px;  
    width:90%;  
    border-radius: 2px;  
    margin: 100px ;  
    background: white;  
    padding: 50px;	
	margin-top: -600px;

}  
input[type="submit"] {
          width: 20%;
          background-color: #384955;
          color: white;
          padding: 14px 20px;
          margin: 8px 0;
          border: none;
          border-radius: 4px;
          cursor: pointer;
		  margin-left: 1000px;
        }

        input[type="submit"]:hover {
          background-color: #C2A7B6;
          color: black;
        }

table {
	border-collapse: collapse;
	margin-right: 30%;
	width:auto;

} 

img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}

table {
	border-collapse: collapse;
	margin-left: auto;
	margin-right: auto;
	width: 80%;
	background: #D3E9FB;

}

table, th, td {
	border: 4px solid black;
}
 .cust {
        color: #000;
        text-transform: uppercase;
        letter-spacing: 2px;
        display: block;
        font-weight: bold;
        font-size: x-large;
        margin-top: 1.5em;
        }


        .container {
        display: flex;
        margin-left: 400px;
        justify-content: center;
        align-items: center;
		margin: 10px;
        }

        .inputBox,
        .inputBox1 {
        position: relative;
        width: 250px;
		margin-left: 150px;
        }

        .inputBox input,
        .inputBox1 input {
        width: 100%;
        padding: 10px;
        outline: none;
        border: none;
        color: #000;
        font-size: 1em;
        background: transparent;
        border-left: 2px solid #000;
        border-bottom: 2px solid #000;
        transition: 0.1s;
        border-bottom-left-radius: 8px;
        }

        .inputBox span,
        .inputBox1 span {
        margin-top: 5px;
        position: absolute;
        left: 0;
        transform: translateY(-4px);
        margin-left: 10px;
        padding: 10px;
        pointer-events: none;
        font-size: 12px;
        color: #000;
        text-transform: uppercase;
        transition: 0.5s;
        letter-spacing: 3px;
        border-radius: 8px;
		gap: 35px;
        }

        .inputBox input:valid~span,
        .inputBox input:focus~span {
        transform: translateX(113px) translateY(-15px);
        font-size: 0.8em;
        padding: 5px 10px;
        background: #000;
        letter-spacing: 0.2em;
        color: #fff;
        border: 2px;
        }

        .inputBox1 input:valid~span,
        .inputBox1 input:focus~span {
        transform: translateX(156px) translateY(-15px);
        font-size: 0.8em;
        padding: 5px 10px;
        background: #000;
        letter-spacing: 0.2em;
        color: #fff;
        border: 2px;
        }

        .inputBox input:valid,
        .inputBox input:focus,
        .inputBox1 input:valid,
        .inputBox1 input:focus {
        border: 2px solid #000;
        border-radius: 8px;
        }

        .enter {
        height: 45px;
        width: 100px;
        border-radius: 5px;
        border: 2px solid #fff;
        cursor: pointer;
        background-color: #384955;
        transition: 0.5s;
        text-transform: uppercase;
        font-size: 10px;
        letter-spacing: 2px;
        margin-bottom: 3em;
		color: white;
        }

        .enter:hover {
        background-color: #C2A7B6;
        color: black;
        }

        .button-container {
        display: flex;
        justify-content: space-between;
        margin-top: 1.8em;
		margin-left: 1000px;
        gap: 15px
        }

</style>
<body>
<div class="dashboard">
<div class="menu-btn">
     <i class="fas fa-bars"></i>
   </div>
   <div class="side-bar">
     <div class="close-btn">
       <i class="fas fa-times"></i>
     </div>
     <div class="menu">
       <div class="item">
         <a class="sub-btn"><i class="fas fa-table"></i>Menu<i class="fas fa-angle-right dropdown"></i></a>
         <div class="sub-menu">
           <a href="bookingpref.php" class="sub-item">Booking</a>
           <a href="bookingdetails.php" class="sub-item">Booking Details</a>
         </div>
       </div>
       <div class="item">
         <a class="sub-btn"><i class="fas fa-cogs"></i>More<i class="fas fa-angle-right dropdown"></i></a>
         <div class="sub-menu">
           <a href="logout.php" class="sub-item">Log Out</a>
         </div>
       </div>
       <div class="item"><a href="about.php"><i class="fas fa-info-circle"></i>About</a></div>
     </div>
   </div>
   <section class="main">
   </section>
  
<div id = "frm">
<h1>ROOM LIST:-</h1>
<br>
				<p>
                <table>
					<tr>
					    <td align=center> ROOM</td>
						<td align=center> PRICE</td>
						<td align=center> TYPE</td>
						<td align=center></td>
					</tr>
					<tr>
						<td align=center> CEMPAKA</td>
						<td align=center> RM 450.00</td>
						<td align=center> SUITE</td>
						<td align=center> <img src="img/suite.png" width="500" </img>
					</tr>
					<tr>
						<td align=center> DAHLIA</td>
						<td align=center> RM 350.00</td>
						<td align=center> FAMILY</td>
						<td align=center> <img src="img/family.png" width="500" </img>
					</tr>
					<tr>
						<td align=center> MELOR</td>
						<td align=center> RM 150.00</td>
						<td align=center> SINGLE</td>
						<td align=center> <img src="img/single.png" width="500" </img>
					</tr>
					<tr>
						<td align=center> ORKID</td>
						<td align=center> RM 250.00</td>
						<td align=center> DELUXE</td>
						<td align=center> <img src="img/deluxe.png" width="500" </img>
					</tr>
					<tr>
						<td align=center> ROSE</td>
						<td align=center> RM 400.00</td>
						<td align=center> CABANA</td>
						<td align=center> <img src="img/cabana.png" width="500" height="100" </img>
					</tr>
					</p>
					</table>
					<br>
					<table>
					<tr>
					   <td align=center>FACILITIES</td>
				    </tr>
					<tr>
					   <td align=center> -SPA AND SAUNA <br> -OUTDOOR DINING <br> -BANQUET FACILITIES <br> -IN-ROOM ARCADE GAMES <br> -LEISURE <br> -FITNESS ROOM <br> -PARTY <br> -CONFERENCE ROOM <br></td>
					   </table>
					<br>
					<br>
			<form action="bookingprocess.php" method="POST">
            <div class="inputBox">
                <input type="text" name="CustID" required="required">
                <span class="user">CUSTOMER ID</span>
            </div>

            <div class="inputBox">
                <input type="text" name="RoomName" required="required">
                <span class="user">ROOM NAME</span>
            </div>

            <div class="inputBox">
                <input type="text" name="RoomType" required="required">
                <span>ROOM TYPE</span>
            </div>
            
            <div class="inputBox">
                <input type="date" name="RoomCin" required="required">
                <span>Check In</span>
            </div>

            <div class="inputBox">
                <input type="date" name="RoomCout" required="required">
                <span>Check Out</span>
            </div>

            <div class="inputBox">
                <input type="text" name="RoomFacilitiesChosen" required="required">
                <span>ROOM FACILITIES CHOSEN</span>
            </div>

            <div class="button-container">
                <button type="submit" class="enter">BOOK</button>
		    </div> 
            </p>
		</form>
	</div>
</div>
	<script type="text/javascript">
   $(document).ready(function(){
     //jquery for toggle sub menus
     $('.sub-btn').click(function(){
       $(this).next('.sub-menu').slideToggle();
       $(this).find('.dropdown').toggleClass('rotate');
     });

     //jquery for expand and collapse the sidebar
     $('.menu-btn').click(function(){
       $('.side-bar').addClass('active');
       $('.menu-btn').css("visibility", "hidden");
     });

     $('.close-btn').click(function(){
       $('.side-bar').removeClass('active');
       $('.menu-btn').css("visibility", "visible");
     });
   });
   </script>

    <script src="js/bootstrap.min.js"></script>

</body>
</html>