-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2023 at 03:42 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homestay`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `BookingID` int(10) NOT NULL,
  `CustID` char(12) NOT NULL,
  `RoomCode` varchar(5) NOT NULL,
  `PaymentID` int(4) NOT NULL,
  `BookingForm` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`BookingID`, `CustID`, `RoomCode`, `PaymentID`, `BookingForm`) VALUES
(1, '010601060512', 'C1', 6566, 'SUCCESSFULLY BOOKED'),
(2, '020911045619', 'C2', 4533, 'SUCCESSFULLY BOOKED'),
(3, '950807115648', 'C3', 6873, 'SUCCESSFULLY BOOKED'),
(4, '970618055966', 'C4', 6800, 'SUCCESSFULLY BOOKED'),
(5, '931101095624', 'D1', 7875, 'SUCCESSFULLY BOOKED'),
(6, '880203025673', 'D2', 7790, 'SUCCESSFULLY BOOKED'),
(7, '910125165619', 'D3', 7719, 'SUCCESSFULLY BOOKED'),
(8, '980215040155', 'D4', 7678, 'SUCCESSFULLY BOOKED'),
(9, '030927076561', 'M1', 3352, 'SUCCESSFULLY BOOKED'),
(10, '031208105675', 'M2', 3330, 'SUCCESSFULLY BOOKED'),
(11, '030912045638', 'M3', 3435, 'SUCCESSFULLY BOOKED'),
(12, '990512145622', 'M4', 3262, 'SUCCESSFULLY BOOKED'),
(13, '020629035679', 'O1', 9689, 'SUCCESSFULLY BOOKED'),
(14, '010831045684', 'O2', 9990, 'SUCCESSFULLY BOOKED'),
(15, '960705085643', 'O3', 9965, 'SUCCESSFULLY BOOKED'),
(16, '990618105648', 'O4', 9976, 'SUCCESSFULLY BOOKED'),
(17, '030723095672', 'R1', 1502, 'SUCCESSFULLY BOOKED'),
(18, '890315085613', 'R2', 1550, 'SUCCESSFULLY BOOKED'),
(19, '960801025677', 'R3', 1789, 'SUCCESSFULLY BOOKED'),
(20, '900514015674', 'R4', 1878, 'SUCCESSFULLY BOOKED');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustID` char(12) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `CustPNum` int(10) NOT NULL,
  `CustName` varchar(50) NOT NULL,
  `CustAddress` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustID`, `username`, `password`, `CustPNum`, `CustName`, `CustAddress`) VALUES
('010601060512', 'batrisyah07', '@bat48', 115489625, 'BATRISYAH BINTI AFFENDY', 'TAMAN SEREMBAN RIA, SEREMBAN 2, 54820, NEGERI SEMBILAN'),
('010831045684', 'marlinalin', 'marlina03', 125489635, 'NUR MARLINA BINTI ISHAK', 'KG PAYA HIJAU, 56893, JOHOR'),
('020629035679', 'farishkm', '@frshakim3', 125684934, 'FARIS HAKIM BIN FAIZUL', 'JALAN TIGA KUPANG, 78425, KEDAH'),
('020911045619', 'adnanakf', 'ad33@', 154786354, 'AKIFF ADNAN BIN JAAFAR', 'JALAN NURI, 89450, JOHOR'),
('030723095672', 'alianasyz', 'alians@', 125489357, 'SYAZA ALIANA BINTI AMIRUL', 'LOT 5648, KG SUNGAI PETANI, 56489 KEDAH'),
('030912045638', 'asykila', 'anakizmer@', 148635792, 'KILA ASYIRAH BINTI IZMER', 'KG PADANG TEMU, 75568, MELAKA'),
('030927076561', 'hafizsyh', 'syah@ram', 148657923, 'HAFIZ SYAH BIN RAMLI', 'LOT 1685, TAMAN SEDAYAN, 45678, PAHANG'),
('031208105675', 'alihamzi', 'abcd@', 135975684, 'ALI BIN HAMZI', 'LOT 4535, 795323, KELANTAN'),
('880203025673', 'tanyi', 'tann09#', 158764932, 'TAN YI LAI', 'TAMAN DALAM, 78156, TERENGGANU'),
('890315085613', 'adamis', 'foreveryou', 189647532, 'ADAM ISKANDAR BIN SHAFIQ ', 'TAMAN SEINDAH, ALOR GAJAH, 56843 MELAKA'),
('900514015674', 'qailis', 'qairikj@', 147965834, 'NUR ALISA QAIRINA BINTI HALIM', 'JALAN 12/1, TAMAN BUKIT KATIL, MELAKA TENGAH, 75605, MELAKA'),
('910125165619', 'irfanzain', 'ahmd44', 178953486, 'AHMAD IRFAN BIN ZAINUDIN', 'JALAN KAKI BUKIT, 78945, PAHANG'),
('931101095624', 'auraqil', 'sugarr#', 168459735, 'AURA AQILA BINTI EDDY', 'TAMAN RIANG 1, 46898, JOHOR'),
('950807115648', 'afrinaaul', 'aulia5', 135486279, 'AFRINA AULIA BINTI SAAHRI', 'TAMAN RAHMAT, JALAN PUDU, 45698 KUALA LUMPUR'),
('960705085643', 'haziqq', 'myhomies#', 154783268, 'MUHAMMAD HAZIQ BIN ALEFF', 'JALAN PUTERI, 45865, NEGERI SEMBILAN'),
('960801025677', 'aniqq', 'aniqafq', 145678235, 'ANIQ AFIQ BIN AZMER', 'TAMAN SENTOSA, PERINGGIT, 76480 MELAKA'),
('970618055966', 'najwaa', 'nrlnjwa', 169748523, 'NURUL NAJWA BINTI ZAINAL', 'TAMAN TUN PERAK, 78658 MELAKA'),
('980215040155', 'm_qil', 'aqilrazif', 157963485, 'MUHAMMAD AQIL BIN RAZIF', 'JALAN 5, TAMAN SERKAM RIA, SERKAM DARAT 77300 MERLIMAU, MELAKA'),
('990512145622', 'amirasof', 'sofea1', 136485972, 'AMIRA SOFEA BINTI FAZIL', 'TAMAN MELUR, 65689, MELAKA'),
('990618105648', 'umairah', 'ctumai', 168745928, 'SITI UMAIRAH BINTI JAMAL', 'TAMAN PERMAI, JALAN LOKE YEW, 65480 KUALA LUMPUR');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` int(4) NOT NULL,
  `PaymentDeposit` decimal(10,2) NOT NULL,
  `PaymentFull` decimal(10,2) NOT NULL,
  `PaymentTransaction` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `PaymentDeposit`, `PaymentFull`, `PaymentTransaction`) VALUES
(1502, 450.00, 1600.00, 'TG11 7100501'),
(1550, 450.00, 800.00, 'TH45 7003401'),
(1789, 450.00, 1200.00, 'TM34 7113231'),
(1878, 450.00, 1600.00, 'FO53 2F1323'),
(3262, 150.00, 300.00, 'FKL5 7434511'),
(3330, 150.00, 300.00, 'LK00 7005104'),
(3352, 150.00, 300.00, 'LL00 7004104'),
(3435, 150.00, 300.00, 'F005 7405114'),
(4533, 350.00, 1800.00, 'EFO1 9277182'),
(6566, 250.00, 1800.00, 'CFO1 9207182'),
(6800, 450.00, 1800.00, 'MD01 3207102'),
(6873, 250.00, 900.00, 'KM11 9207102'),
(7678, 350.00, 700.00, 'MM05 7204104'),
(7719, 450.00, 1400.00, 'LK89 9204104'),
(7790, 450.00, 1050.00, 'RL14 8207104'),
(7875, 450.00, 1050.00, 'MK00 9207104'),
(9689, 200.00, 500.00, 'FEL3 7230511'),
(9965, 450.00, 1250.00, 'AM23 7000501'),
(9976, 450.00, 1000.00, 'TR20 7110501'),
(9990, 200.00, 500.00, 'FL23 7000511');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `RoomCode` varchar(5) NOT NULL,
  `CustID` char(12) NOT NULL,
  `RoomName` varchar(10) NOT NULL,
  `RoomPrice` decimal(10,2) NOT NULL,
  `RoomType` varchar(25) NOT NULL,
  `RoomCin` datetime NOT NULL,
  `RoomCout` datetime NOT NULL,
  `RoomHouseKeeping` datetime NOT NULL,
  `RoomFacilitiesChosen` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`RoomCode`, `CustID`, `RoomName`, `RoomPrice`, `RoomType`, `RoomCin`, `RoomCout`, `RoomHouseKeeping`, `RoomFacilitiesChosen`) VALUES
('C1', '010601060512', 'CEMPAKA', 450.00, 'SUITE', '2023-05-16 16:00:00', '2023-05-20 12:30:00', '2023-05-20 12:45:00', 'SPA AND SAUNA'),
('C2', '020911045619', 'CEMPAKA', 450.00, 'SUITE', '2023-05-20 16:00:00', '2023-05-24 12:30:00', '2023-05-24 12:45:00', 'SPA AND SAUNA'),
('C3', '950807115648', 'CEMPAKA', 450.00, 'SUITE', '2023-05-24 16:00:00', '2023-05-28 12:30:00', '2023-05-28 12:45:00', 'OUTDOOR DINING'),
('C4', '970618055966', 'CEMPAKA', 450.00, 'SUITE', '2023-05-28 16:00:00', '2023-05-30 12:30:00', '2023-05-30 12:45:00', 'OUTDOOR DINING'),
('D1', '931101095624', 'DAHLIA', 350.00, 'FAMILY', '2023-05-10 14:30:00', '2023-05-13 12:30:00', '2023-05-13 12:45:00', 'BANQUET FACILITIES'),
('D2', '880203025673', 'DAHLIA', 350.00, 'FAMILY', '2023-05-13 14:00:00', '2023-05-16 12:30:00', '2023-05-16 12:45:00', 'BANQUET FACILITIES'),
('D3', '910125165619', 'DAHLIA', 350.00, 'FAMILY', '2023-05-17 14:00:00', '2023-05-21 12:30:00', '2023-05-21 12:45:00', 'IN-ROOM ARCADE GAMES'),
('D4', '980215040155', 'DAHLIA', 350.00, 'FAMILY', '2023-05-24 14:00:00', '2023-05-26 12:30:00', '2023-05-26 12:45:00', 'IN-ROOM ARCADE GAMES'),
('M1', '030927076561', 'MELOR', 150.00, 'SINGLE', '2023-05-21 14:30:00', '2023-05-23 12:00:00', '2023-05-23 12:00:00', 'FITNESS ROOM'),
('M2', '031208105675', 'MELOR', 150.00, 'SINGLE', '2023-05-23 14:00:00', '2023-05-25 12:00:00', '2023-05-25 12:00:00', 'FITNESS ROOM'),
('M3', '030912045638', 'MELOR', 150.00, 'SINGLE', '2023-05-25 14:00:00', '2023-05-27 12:00:00', '2023-05-27 12:00:00', 'CONFERENCE ROOM'),
('M4', '990512145622', 'MELOR', 150.00, 'SINGLE', '2023-05-27 14:00:00', '2023-05-29 12:00:00', '2023-05-29 12:00:00', 'CONFERENCE ROOM'),
('O1', '020629035679', 'ORKID', 250.00, 'DELUXE', '2023-05-20 14:30:00', '2023-05-22 12:30:00', '2023-05-22 12:45:00', 'CONFERENCE ROOM'),
('O2', '010831045684', 'ORKID', 250.00, 'DELUXE', '2023-05-22 14:30:00', '2023-05-24 12:30:00', '2023-05-24 12:45:00', 'CONFERENCE ROOM'),
('O3', '960705085643', 'ORKID', 250.00, 'DELUXE', '2023-05-25 14:30:00', '2023-05-30 12:30:00', '2023-05-30 12:45:00', 'SPA AND SAUNA'),
('O4', '990618105648', 'ORKID', 250.00, 'DELUXE', '2023-05-30 14:30:00', '2023-06-03 12:30:00', '2023-06-03 12:45:00', 'SPA AND SAUNA'),
('R1', '030723095672', 'ROSE', 400.00, 'CABANA', '2023-05-20 14:00:00', '2023-05-24 12:45:00', '2023-05-24 13:00:00', 'BANQUET FACILITIES'),
('R2', '890315085613', 'ROSE', 400.00, 'CABANA', '2023-05-24 14:00:00', '2023-05-26 12:45:00', '2023-05-26 13:00:00', 'BANQUET FACILITIES'),
('R3', '960801025677', 'ROSE', 400.00, 'CABANA', '2023-05-27 14:00:00', '2023-05-30 12:45:00', '2023-05-30 13:00:00', 'BANQUET FACILITIES'),
('R4', '900514015674', 'ROSE', 400.00, 'CABANA', '2023-05-30 14:00:00', '2023-06-03 12:45:00', '2023-06-03 13:00:00', 'BANQUET FACILITIES');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `ScheduleID` int(2) NOT NULL,
  `StaffID` int(2) NOT NULL,
  `RoomCode` varchar(2) NOT NULL,
  `ScheduleTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`ScheduleID`, `StaffID`, `RoomCode`, `ScheduleTime`) VALUES
(1, 5, 'C1', '2023-05-20 12:45:00'),
(2, 3, 'C2', '2023-05-24 12:45:00'),
(3, 1, 'C3', '2023-05-28 12:45:00'),
(4, 2, 'C4', '2023-05-30 12:45:00'),
(5, 4, 'D1', '2023-05-13 12:45:00'),
(6, 6, 'D2', '2023-05-16 12:45:00'),
(7, 7, 'D3', '2023-05-21 12:45:00'),
(8, 8, 'D4', '2023-05-26 12:45:00'),
(9, 9, 'M1', '2023-05-23 12:00:00'),
(10, 10, 'M2', '2023-05-25 12:00:00'),
(11, 11, 'M3', '2023-05-27 12:00:00'),
(12, 12, 'M4', '2023-05-29 12:00:00'),
(13, 13, 'O1', '2023-05-22 12:45:00'),
(14, 14, 'O2', '2023-05-24 12:45:00'),
(15, 15, 'O3', '2023-05-30 12:45:00'),
(16, 16, 'O4', '2023-06-03 12:45:00'),
(17, 17, 'R1', '2023-05-24 13:00:00'),
(18, 18, 'R2', '2023-05-26 13:00:00'),
(19, 19, 'R3', '2023-05-30 13:00:00'),
(20, 20, 'R4', '2023-06-03 13:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` int(2) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `StaffName` varchar(50) NOT NULL,
  `StaffPhNum` int(10) NOT NULL,
  `StaffAddress` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `username`, `password`, `StaffName`, `StaffPhNum`, `StaffAddress`) VALUES
(1, 'hafiz', 'mhafiz2', 'MUHAMMAD HAFIZ BIN SALEH', 169700891, 'Jalan S2 A40, 70200, Seremban '),
(2, 'insyira', 'ctinsyi3', 'SITI INSYIRA BINTI AZIM', 126544900, 'Jalan Dato Klana, 70200, Seremban'),
(3, 'amirul', 'aarifjzli', 'AMIRUL ARIF BIN JAZLI', 146309182, 'Kg Lubok, Mulong, Kota Bharu,16450, Kelantan'),
(4, 'aulia', 'aulfauzi', 'AULIA BINTI FAUZI', 16352363, 'Taman Rembia Cemerlang, Rembia, 78000, Melaka'),
(5, 'iqhbal', 'iqhthefish', 'IQHBAL AL\'FAJR', 16352363, 'Lot 5362, Taman Bukit Tebu,Tanah Merah, Kelantan'),
(6, 'mastura', 'mas45#', 'MASTURA BINTI AZLIM', 179097342, '83, Jalan Medang, Bangsar, 59000, Kuala Lumpur'),
(7, 'johari', 'jo35@', 'JOHARI BIN TALIL', 188717983, 'Semabok ,Melaka Tengah, 75050, Melaka'),
(8, 'saniy', 'san67#', 'SANIY BIN AZLIM', 179097344, 'Jalan Dahlia, Melaka Tengah, 75250, Melaka'),
(9, 'aidil', 'mohd22#', 'MOHAMED AIDIL BIN MOHAMED AZLIM', 16352363, 'Taman Permatang Pasir Permai, 75050, Melaka'),
(10, 'sufian', '90sufian', 'SUFIAN LIM XI ZHAO BIN AZLIM', 126544901, 'Jalan Nusa Intan 6/7, Senawang, 70200 ,Seremban\r\n'),
(11, 'dahlia', '11dahlia@', 'DAHLIA HUSNA BINTI KARIM', 194913226, 'Bandar Sri Sendayan, 70200, Seremban'),
(12, 'ayuni', 'shafyun3', 'SHAFI AYUNI BINTI OTHMAN', 121225036, 'Bandar Baru Nilai, 71800, Nilai'),
(13, 'akmar', 'mar34', 'AKMAR BINTI RAUF', 136447365, 'Persiaran Utama S2/3, 70200, Seremban'),
(14, 'iman', 'n@iman', 'NURUL IMAN BINTI ROZI', 120959064, 'Jalan Indah 2/8, Taman Jade Hill, 73000, Tampin'),
(15, 'ainaa', 'sha55#', 'SHA AINAA BINTI RAIF', 196642123, 'Setapak, 53000, Kuala Lumpur'),
(16, 'raid', 'rhkm#', 'RAID HAKIM BIN AZIZI', 126544904, 'Desa Setapak, 53300, Kuala Lumpur'),
(17, 'rahimi', 'r@himi3', 'RAHIMI BIN ALI', 188717977, 'Taman Tehel Indah, Hang Tuah Jaya, 75450, Melaka'),
(18, 'firdaus', 'fird@us2', 'AHMAD FIRDAUS BIN DAHLAN', 137712745, 'Jalan Idaman , Taman Kelubi Idaman, 77000, Melaka'),
(19, 'amir', 'uwaisrt2', 'AMIR UWAIS BIN RAHMAT', 169342334, 'Jalan MP 8, Taman Merdeka Permai, 75350, Melaka'),
(20, 'aniqh', '@niq11', 'ANIQ HAKIMIE BIN SAIDI', 146305774, 'Jalan Syahbandar, Kota Laksamana, 75200, Melaka');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `password`) VALUES
(1, 'ainal', 'AIN ALIYAH', 'aliyah##'),
(2, 'aliff', 'ALIFF AIMAN', 'aliff##'),
(3, 'hariz', 'HARIZ SHAFIE', 'hariz##'),
(4, 'liyazlif', 'DEVELOPERS', 'airiwial'),
(5, 'rwiyah', 'RABIATUL ADAWIYAH', 'rabi##');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`BookingID`),
  ADD UNIQUE KEY `CustID` (`CustID`),
  ADD UNIQUE KEY `RoomCode` (`RoomCode`,`PaymentID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`RoomCode`),
  ADD UNIQUE KEY `CustID` (`CustID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`ScheduleID`),
  ADD UNIQUE KEY `RoomCode` (`RoomCode`),
  ADD UNIQUE KEY `StaffID` (`StaffID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `BookingID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `PaymentID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9991;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `ScheduleID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `StaffID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
