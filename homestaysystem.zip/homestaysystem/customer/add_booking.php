<?php
include './db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $CustID = $_POST['CustID'];     
  $username = $_POST['username'];  
  $password = $_POST['password'];
  $CustPNum = $_POST['CustPNum'];   
  $CustName = $_POST['CustName'];    
  $CustAddress = $_POST['CustAddress'];       

  $query = "INSERT * FROM customer WHERE CustID = '$CustID' AND username = '$username' AND password = '$password' AND CustPNum = '$CustPNum' AND CustName = '$CustName' AND CustAddress = '$CustAddress'";
  $result = mysqli_query($connection, $query);

  if ($result && mysqli_num_rows($result) > 0) {
    // Login successful, redirect to a success page
    header("Location: login.php");
    exit();
  } else {
    // Invalid login
    echo "<script>
      alert('Invalid login credentials!');
      window.location.href = 'signin.php';
    </script>";
  }
}
?>