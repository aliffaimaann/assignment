<?php
include './db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $CustID = $_POST['CustID'];   	
  $username = $_POST['username'];  
  $password = $_POST['password'];
  $CustPNum = $_POST['CustPNum'];   
  $CustName = $_POST['CustName'];    
  $CustAddress = $_POST['CustAddress'];       

  $query = "INSERT INTO customer (CustID, username, password, CustPNum, CustName, CustAddress) VALUES ('$CustID', '$username', '$password', '$CustPNum', '$CustName', '$CustAddress')";
  $result = mysqli_query($connection, $query);

  if ($result) {
    // Insert successful, redirect to a success page
    header("Location: bookingpref.php");
    exit();
  } else {
    // Insert failed
    echo "<script>
      alert('Failed to insert data!');
      window.location.href = 'signin.php';
    </script>";
  }
}
?>


