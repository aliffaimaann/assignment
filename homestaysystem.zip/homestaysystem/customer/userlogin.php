<?php
    include './db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  $query = "SELECT * FROM customer WHERE username = '$username' AND password = '$password'";
  $result = mysqli_query($connection, $query);

  if (mysqli_num_rows($result) == 1) {
    // Valid login
    $row = mysqli_fetch_assoc($result);
    header("Location: customer/bookingpref.php"); 
    exit();
  } else {
    // Invalid login
    echo "<script>
      alert('Please sign up first before login!');
      window.location.href = 'login.php';
      
    </script>";
  }
}
?>