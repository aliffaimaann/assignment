<?php
$password = $_GET['pass'];
$dbc = mysqli_connect ("localhost", "root", "","homestay");
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql = "update `users` set `password`='$password'";
$result = mysqli_query($dbc, $sql);
if($result)
{
mysqli_commit($dbc);
Print '<script>alert("Password is successfully changed.");</script>';
}
else
{
mysqli_rollback($dbc);
Print '<script>alert("Password is failed to changed.");</script>';
}
?>